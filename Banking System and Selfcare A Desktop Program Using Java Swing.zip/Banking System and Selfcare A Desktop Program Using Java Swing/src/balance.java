/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author M. Israk Ahmed
 */
public class balance {
    private int account_id;
     private int current_balance;
      private int withdrawable;
      
      public balance(int Account_id,int Current_balance,int Withdrawable){
          this.account_id=Account_id;
          this.current_balance=Current_balance;
           this.withdrawable=Withdrawable;
                  
      }
     public int getAccountId(){
        return account_id; 
    }
    public int getCurrentBalance(){
        return current_balance;
    }
      public int getWithdrawable(){
        return withdrawable;
    }
}
