/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author M. Israk Ahmed
 */
public class services {
    private int service_code;
    private int merchant_id;
    private int service_rating;
    private String service_details;

    public services(int Service_code,int Merchant_id,int Service_rating,String Service_details){
        this.service_code=Service_code;
        this.merchant_id=Merchant_id;
        this.service_rating=Service_rating;
        this.service_details=Service_details; 
    }
    
         public int getServiceCode(){
        return service_code; 
    }
      public int getMerchantID(){
        return merchant_id; 
    }
    public int getServiceRating(){
        return service_rating;
    }
    public String getServiceDetails(){
        return service_details;
    }
    
}
