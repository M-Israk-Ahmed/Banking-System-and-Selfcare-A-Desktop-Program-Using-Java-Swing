
import java.util.Date;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author M. Israk Ahmed
 */
public class accounts {
    private int account_id;
    private int account_type_code;
    private int customer_id;
    private String account_name;
    private Date account_opening;
    
    public accounts(int Account_id,int Account_type_code,int Customer_id,String Account_name,Date Account_opening){
        this.account_id=Account_id;
           this.account_type_code=Account_type_code;
           this.customer_id=Customer_id;
           this.account_name=Account_name;
           this.account_opening=Account_opening;
    }
    
     public int getAccountId(){
        return account_id; 
    }
      public int getAccountTypeCode(){
        return account_type_code; 
    }
    public int getCustomerID(){
        return customer_id;
    }
    public String getAccountName(){
        return account_name;
    }
    public Date getAccountOpening(){
        return account_opening;  
}
}
