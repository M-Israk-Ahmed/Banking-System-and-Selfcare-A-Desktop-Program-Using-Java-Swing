/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author M. Israk Ahmed
 */
public class customer {
    private int id;
    private String ctype;
    private String cname;
    private int age;
    private String gender;
    private String cphone;
    private String cmail;
    private String userid;
    private String userpass;
    private byte[] picture;
    private String securityque;
    
    public customer(int Customer_id,String Customer_type,String Customer_name,int Age,String Gender,String Customer_phone,String Customer_mail,String User_id,String User_pass,byte[] Image,String Security_question){
        this.id=Customer_id;
        this.ctype=Customer_type;
        this.cname=Customer_name;
        this.age=Age;
        this.gender=Gender;
        this.cphone=Customer_phone;
        this.cmail=Customer_mail;
        this.userid=User_id;
        this.userpass=User_pass;
        this.picture=Image;
        this.securityque=Security_question;
                
    }
    
    public int getCustomerId(){
        return id; 
    }
    public String getCustomerType(){
        return ctype;
    }
    public String getCustomerName(){
        return cname;
    }
    public int getAge(){
        return age;
    }
    public String getGender(){
        return gender;
        
    }
    public String getCustomerphone(){
        return cphone;
    }
    public String getCustomermail(){
        return cmail;
    }
    public String getUserId(){
        return userid;
    }
    public String getUserPass(){
    return userpass;
    }
   
  public byte[] getImage(){
      return picture;
  }
  public String getSecurityQuestion(){
      return securityque;
  }
  
}


