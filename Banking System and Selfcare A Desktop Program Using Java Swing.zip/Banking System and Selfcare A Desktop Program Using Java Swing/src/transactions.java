
import java.util.Date;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author M. Israk Ahmed
 */
public class transactions {
    private int transaction_id;
    private int account_id;
    private int purchase_id;
    private Date transaction_date;
    private int total_transaction;
    private int available_balance;
    
    public transactions(int Transaction_id,int Account_id,int Purchase_id,Date Transaction_date,int Total_transaction,int Available_balance){
        this.transaction_id=Transaction_id;
        this.account_id=Account_id;
        this.purchase_id=Purchase_id;
        this.transaction_date=Transaction_date;
        this.total_transaction=Total_transaction;
        this.available_balance=Available_balance;
    }
    
      public int getAccountID(){
        return account_id; 
    }
      public int getTransactionID(){
        return transaction_id; 
    }
    public int getPurchaseID(){
        return purchase_id;
    }
    public int getTotalTransaction(){
        return total_transaction;
    }
        public int getAvailableBalance(){
        return available_balance;
    }
    public Date getTransactionDate(){
        return transaction_date;  
}
    
}
