
import java.util.Date;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author M. Israk Ahmed
 */
public class purchase {
    private int purchase_id;
    private int customer_id;
    private int service_code;
    private Date purchase_date;
    private int quantity; 
    private int total_amount;

    public purchase(int Purchase_id,int Customer_id,int Service_code,Date Purchase_date,int Quantity,int Total_amount){
        this.customer_id=Customer_id;
        this.purchase_date=Purchase_date;
                this.purchase_id=Purchase_id;
                        this.quantity=Quantity;
                                this.service_code=Service_code;
                                        this.total_amount=Total_amount;
        
    }
    
         public int getTotalAmount(){
        return total_amount; 
    }
      public int getPurchaseId(){
        return purchase_id; 
    }
    public int getCustomerID(){
        return customer_id;
    }
    public int getQuantity(){
        return quantity;
    }
        public int getServiceCode(){
        return service_code;
    }
    public Date getPurchaseDate(){
        return purchase_date;  
}
    
}
