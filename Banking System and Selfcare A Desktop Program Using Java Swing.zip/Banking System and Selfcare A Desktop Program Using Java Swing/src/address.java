/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author M. Israk Ahmed
 */
public class address {
   private int address_id;
   private int customer_id;
   private String present_address;
   private String pre_house_no;
   private int pre_house_line;
   private int pre_Office_line;
    private String pre_post_code;
     private String parmanent_address;
     private String par_house_no;
     private int par_house_line;
     private int par_office_line;
     private String par_post_code;
     
     public address(int Address_id,int Customer_id,String Present_address,String Pre_house_no,int Pre_house_line,int Pre_Office_line,String Pre_post_code,String Parmanent_address,String Par_house_no,int Par_house_line,int Par_office_line,String Par_post_code){
        this.address_id= Address_id;
        this.customer_id=Customer_id;
                this.present_address=Present_address;
                this.pre_house_no=Pre_house_no;
                this.pre_house_line=Pre_house_line;
                this.pre_Office_line=Pre_Office_line;
                this.pre_post_code=Pre_post_code;
                this.parmanent_address=Parmanent_address;
                this.par_house_no=Par_house_no;
                this.par_house_line=Par_house_line;
                this.par_office_line=Par_office_line;
                this.par_post_code=Par_post_code;       
     }
     
     public int getAddressId(){
        return address_id; 
    }
    public int getCustomerID(){
        return customer_id;
    }
    public String getPresentAddress(){
        return present_address;
    }
    public String getPresentHouseNo(){
        return pre_house_no;
    }
    public int getPresentHouseLine(){
        return pre_house_line;
        
    }
    public int getPresentOfficeLine(){
        return pre_Office_line;
    }
    public String getPresentPostCode(){
        return pre_post_code;
    }
        public String getParmanentAddress(){
        return parmanent_address;
    }
    public String getParmanentHouseNo(){
        return par_house_no;
    }
    public int getParmanentHouseLine(){
        return par_house_line;
        
    }
    public int getParmanentOfficeLine(){
        return par_office_line;
    }
    public String getParmanentPOstCode(){
        return par_post_code;
    }
    
}

