
import com.placeholder.PlaceHolder;
import java.awt.Color;
import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.Timer;
import static javax.swing.UIManager.getInt;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author M. Israk Ahmed
 */
public class menu extends javax.swing.JFrame {
    
Connection con=null;
ResultSet rs=null;
PreparedStatement pst=null; 
   String filename=null;
   byte[] p_image=null;    
   byte[] imageBytes;
private ImageIcon format=null;
PlaceHolder p,q,r,t,u,v;
int mouseX;
    int mouseY;
       int c_id;
   int address_id;
   int account_id;
   int acc_type_code;
   int cus_type_code;
      int s=0;
   int m=0;
   int n=0;




    public menu() {
        con=Connect.ConnectDB();
        ImageIcon icon = new ImageIcon("image/sb.png");
        setIconImage(icon.getImage());
        initComponents();
        showDate();
        time();

        Show_Users_In_JTable();
        Panel2_table();
        Panel_Table3();
        jTable2();
        Panel4_table();
        Panel5_table();
        jTable3();
        Panel3_table();
                
        FillCombo1();
        FillCombo2();
        
        occ.setSelectedItem(null);
        acc_type.setSelectedItem(null);
        
        genC_ID();
        genAccount_ID();
        genAddress_ID();
        
        
         
        setColor(btn_cust_manipulation);
        btn_cust_manipulation.setOpaque(true);
         ind_cust_manipulation.setOpaque(true);
        jLabel1.setFont(new  Font("Centry Gothic",Font.BOLD,15));
        
    }
    
    
    
    public void showDate(){
        Date d = new Date();
        SimpleDateFormat s=new SimpleDateFormat("yyyy-MM-dd");
        date1.setText(s.format(d));
    }
    public void time(){
        new Timer(0, new ActionListener(){
            public void actionPerformed(ActionEvent e){
                java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("HH:mm:ss");
                String text_date = sdf.format(new Date());
                time.setText(text_date);
            }
        }).start();
        }
    
    public void getSum(){
        int rowsCount= Panel3_table.getRowCount();
        int sum=0;
        for (int i=0;i<rowsCount;i++){
            if(date1.getText().equals(Panel3_table.getValueAt(i, 3).toString())){
                
                sum=sum + Integer.parseInt(Panel3_table.getValueAt(i,4).toString());
            }     
        }
                Tsum.setText(Integer.toString(sum));
    }
    

    public void executeSQlQuery(String query, String message)
   {
       con=Connect.ConnectDB();
       Statement st;
       try{
           st = con.createStatement();
           if((st.executeUpdate(query)) == 1)
           {
               // refresh jtable data
               DefaultTableModel model = (DefaultTableModel)jTable_Display_Users.getModel();
               model.setRowCount(0);
               Show_Users_In_JTable();
               
               JOptionPane.showMessageDialog(null, "Data "+message+" Succefully");
           }else{
               JOptionPane.showMessageDialog(null, "Data Not "+message);
           }
       }catch(Exception ex){
           ex.printStackTrace();
       }
   }
    
    
    public ArrayList<customer> getUsersList()
   {
        con=Connect.ConnectDB();
       ArrayList<customer> customersList = new ArrayList<customer>();
       //Connection connection = getConnection();
       
       String query = "SELECT * FROM  customers ";
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);
           customer cust;
           while(rs.next())
           {
               //user = new User(rs.getInt("id"),rs.getString("fname"),rs.getString("lname"),rs.getInt("age"));
               cust = new customer(rs.getInt("Customer_id"),rs.getString("Customer_type_code"),rs.getString("Customer_name"),rs.getInt("Age") ,rs.getString("Gender"),rs.getString("Customer_phone"),rs.getString("Customer_mail"),rs.getString("User_id"),rs.getString("User_pass"),rs.getBytes("Image"),rs.getString("Security_question"));
  
               customersList.add(cust);
           }
       } catch (Exception e) {
           e.printStackTrace();
       }
       return customersList;
   }
   
   // Step-5: Display Data In JTable
   
    /**
     *
     */
       
   public void Show_Users_In_JTable()
   {
       ArrayList<customer> list = getUsersList();
       DefaultTableModel model = (DefaultTableModel)jTable_Display_Users.getModel();
       Object[] row = new Object[4];
       for(int i = 0; i < list.size(); i++)
       {
           row[0] = list.get(i).getCustomerId();
           row[1] = list.get(i).getCustomerName();
           row[2] = list.get(i).getCustomerphone();
           row[3] = list.get(i).getAge();
           
           model.addRow(row);
       }
    }

    public void genC_ID(){
       try{ 
      String sql= "select Customer_id from customers order by Customer_id desc limit 1";
      pst=con.prepareStatement(sql);
      rs= pst.executeQuery();
        if(rs.next()){
            String id3 = rs.getString("Customer_id").trim();
            c_id=Integer.parseInt(id3);
            c_id++;
        }
        else{
            c_id=1;
        }
       }
       catch(Exception e){
          JOptionPane.showMessageDialog(null,e); 
       }
    
    }
    public void genAccount_ID(){
        
        try{ 
      String sql= "select Account_id from accounts order by Account_id desc limit 1";
      pst=con.prepareStatement(sql);
      rs= pst.executeQuery();
        if(rs.next()){
            String id2 = rs.getString("Account_id").trim();
            account_id=Integer.parseInt(id2);
            account_id++;
        }
        else{
            account_id=4001;
        }
       }
       catch(Exception e){
          JOptionPane.showMessageDialog(null,e); 
       }
        
    }
    public void genAddress_ID(){
        
        try{ 
      String sql= "select Address_id from address order by Address_id desc limit 1";
      pst=con.prepareStatement(sql);
      rs= pst.executeQuery();
        if(rs.next()){
            String id1 = rs.getString("Address_id").trim();
            address_id=Integer.parseInt(id1);
            address_id++;
        }
        else{
           address_id=501;
        }
       }
       catch(Exception e){
          JOptionPane.showMessageDialog(null,e); 
       }
        
    }
    
    public void FillCombo1(){
        try{ 
      String sql= "select * from customer_type";
      pst=con.prepareStatement(sql);
      rs= pst.executeQuery();
        while(rs.next()){
            String type = rs.getString("Customer_type").trim();
           occ.addItem(type);
        }
        
       }
       catch(Exception e){
          JOptionPane.showMessageDialog(null,e); 
       }
        
    }
    
       public void FillCombo2(){
        try{ 
      String sql= "select * from account_type";
      pst=con.prepareStatement(sql);
      rs= pst.executeQuery();
        while(rs.next()){
            String type = rs.getString("Account_type").trim();
           acc_type.addItem(type);
        }
        
       }
       catch(Exception e){
          JOptionPane.showMessageDialog(null,e); 
       }
        
    }
    
       public void FillAccount(){
        
        try{
            con=Connect.ConnectDB();
            Image image;
            int i = jTable_Display_Users.getSelectedRow();
           String x=jTable_Display_Users.getModel().getValueAt(i,0).toString();
            
            //DefaultTableModel model;
        String query5= "select * from customers where Customer_id= '" +x+ "'";
        pst=con.prepareStatement(query5);
        rs= pst.executeQuery();
        if(rs.next()){
            String ge = rs.getString("Gender").trim();
            String cusmail = rs.getString("Customer_mail").trim();
            String uid = rs.getString("User_id").trim();
            String upass = rs.getString("User_pass").trim();
            String type = rs.getString("Customer_type_code").trim();
            String ans = rs.getString("Security_question").trim();
             imageBytes=rs.getBytes("Image");
            image=getToolkit().createImage(imageBytes);
            ImageIcon icon = new ImageIcon(image);
            Image im=icon.getImage();
            Image myImage=im.getScaledInstance(lbl_img.getWidth(), lbl_img.getHeight(), Image.SCALE_SMOOTH);
            ImageIcon newicon = new ImageIcon(myImage);
            
            lbl_img.setIcon(newicon);
            gender.setSelectedItem(ge);
            mail.setText(cusmail);   
             user_name.setText(uid);
             user_pass.setText(upass);
             fav_pet.setText(ans);
               String query10= "select * from customer_type where Customer_type_code= '" +type+ "'";
                pst=con.prepareStatement(query10);
                rs= pst.executeQuery();
              if(rs.next()){
              String cusype = rs.getString("Customer_type").trim();
             occ.setSelectedItem(cusype);
                 }
        }
       
        
        String query6= "select * from accounts where Customer_id= '" +x+ "'";
        pst=con.prepareStatement(query6);
        rs= pst.executeQuery();
        if(rs.next()){
           String opdate = rs.getString("Account_opening").trim(); 
           String accountname = rs.getString("Account_name").trim(); 
           String accountype = rs.getString("Account_type_code").trim();
           date.setDate(new SimpleDateFormat("yyyy-MM-dd").parse(opdate));
           acc_name.setText(accountname);
           
            String query9= "select * from account_type where Account_type_code= '" +accountype+ "'";
        pst=con.prepareStatement(query9);
        rs= pst.executeQuery();
        if(rs.next()){
           String acctype = rs.getString("Account_type").trim();
           acc_type.setSelectedItem(acctype);
                }
        }
        
        
        String query11= "select * from address where Customer_id= '" +x+ "'";
        pst=con.prepareStatement(query11);
        rs= pst.executeQuery();
        if(rs.next()){
           String a1 = rs.getString("Present_address").trim(); 
           String a2 = rs.getString("Pre_house_no").trim(); 
           String a3 = rs.getString("Pre_house_line").trim(); 
           String a4 = rs.getString("Pre_Office_line").trim(); 
           String a5 = rs.getString("Pre_post_code").trim(); 
           String a6 = rs.getString("Parmanent_address").trim(); 
           String a7 = rs.getString("Par_house_no").trim(); 
           String a8 = rs.getString("Par_house_line").trim();
           String a9 = rs.getString("Par_office_line").trim(); 
           String a10 = rs.getString("Par_post_code").trim();
               parmanent_add.setText(a6);
               present_add.setText(a1);
               parmanent_house_no.setText(a7);
               present_house_no.setText(a2);
               parmanent_house_line.setText(a8);
               present_house_line.setText(a3);
               parmanent_office_line.setText(a9);
               present_office_line.setText(a4);
               parmanent_post_code.setText(a10);
               present_post_code.setText(a5);
        }
         
        }
 
       
        catch(Exception e){
            JOptionPane.showMessageDialog(this,e);
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btn_rec_manipulation = new javax.swing.JPanel();
        ind_myacc = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btn_sdb = new javax.swing.JPanel();
        ind_myacc3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        btn_add_table = new javax.swing.JPanel();
        ind_add_table = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        btn_cust_table = new javax.swing.JPanel();
        ind_cust_table = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        btn_acc_table = new javax.swing.JPanel();
        ind_acc_table = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        btn_balance_table = new javax.swing.JPanel();
        ind_balance_table = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        btn_purchase_table = new javax.swing.JPanel();
        ind_purchase_table = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        btn_service_table = new javax.swing.JPanel();
        ind_service_table = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        btn_transaction_table = new javax.swing.JPanel();
        ind_transaction_table = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        btn_cust_manipulation = new javax.swing.JPanel();
        ind_cust_manipulation = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        btn_about = new javax.swing.JPanel();
        ind_about = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        btn_about1 = new javax.swing.JPanel();
        ind_about1 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        btn_logout = new javax.swing.JPanel();
        ind_logout = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        date1 = new javax.swing.JLabel();
        time = new javax.swing.JLabel();
        panelHeader = new javax.swing.JPanel();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        present_house_no = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        present_house_line = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        present_add = new javax.swing.JTextArea();
        jLabel18 = new javax.swing.JLabel();
        present_office_line = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        present_post_code = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        parmanent_office_line = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        parmanent_house_line = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        parmanent_add = new javax.swing.JTextArea();
        parmanent_post_code = new javax.swing.JTextField();
        parmanent_house_no = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        btnImage = new javax.swing.JButton();
        jDesktopPane1 = new javax.swing.JDesktopPane();
        lbl_img = new javax.swing.JLabel();
        jRadioButton1 = new javax.swing.JRadioButton();
        jPanel5 = new javax.swing.JPanel();
        jLabel26 = new javax.swing.JLabel();
        phone = new javax.swing.JTextField();
        gender = new javax.swing.JComboBox();
        age = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        name = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        occ = new javax.swing.JComboBox();
        jLabel31 = new javax.swing.JLabel();
        mail = new javax.swing.JTextField();
        jPanel7 = new javax.swing.JPanel();
        jLabel32 = new javax.swing.JLabel();
        acc_name = new javax.swing.JTextField();
        jLabel33 = new javax.swing.JLabel();
        user_name = new javax.swing.JTextField();
        user_pass = new javax.swing.JPasswordField();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        date = new com.toedter.calendar.JDateChooser();
        acc_type = new javax.swing.JComboBox();
        fav_pet = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable_Display_Users = new javax.swing.JTable();
        jPanel8 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        insert = new javax.swing.JButton();
        update = new javax.swing.JButton();
        delete = new javax.swing.JButton();
        clear = new javax.swing.JButton();
        next = new javax.swing.JButton();
        last = new javax.swing.JButton();
        first = new javax.swing.JButton();
        previous = new javax.swing.JButton();
        jPanel10 = new javax.swing.JPanel();
        search = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        hidelvl = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        search1 = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        Panel2_table = new javax.swing.JTable();
        jPanel13 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jLabel38 = new javax.swing.JLabel();
        search2 = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        Panel_Table3 = new javax.swing.JTable();
        jPanel15 = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        jLabel39 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jPanel17 = new javax.swing.JPanel();
        jPanel18 = new javax.swing.JPanel();
        jLabel40 = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        Panel4_table = new javax.swing.JTable();
        jPanel19 = new javax.swing.JPanel();
        jPanel20 = new javax.swing.JPanel();
        jLabel41 = new javax.swing.JLabel();
        jScrollPane8 = new javax.swing.JScrollPane();
        Panel5_table = new javax.swing.JTable();
        jPanel21 = new javax.swing.JPanel();
        jPanel22 = new javax.swing.JPanel();
        jLabel42 = new javax.swing.JLabel();
        jScrollPane9 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jPanel23 = new javax.swing.JPanel();
        jPanel24 = new javax.swing.JPanel();
        jLabel43 = new javax.swing.JLabel();
        search5 = new javax.swing.JTextField();
        jButton4 = new javax.swing.JButton();
        jScrollPane10 = new javax.swing.JScrollPane();
        Panel3_table = new javax.swing.JTable();
        jLabel47 = new javax.swing.JLabel();
        Tsum = new javax.swing.JTextField();
        jPanel25 = new javax.swing.JPanel();
        jPanel27 = new javax.swing.JPanel();
        jLabel49 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel48 = new javax.swing.JLabel();
        jPanel26 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                formMouseDragged(evt);
            }
        });
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                formMousePressed(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(47, 3, 54));

        btn_rec_manipulation.setBackground(new java.awt.Color(77, 16, 135));
        btn_rec_manipulation.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_rec_manipulationMousePressed(evt);
            }
        });

        ind_myacc.setOpaque(false);
        ind_myacc.setPreferredSize(new java.awt.Dimension(3, 31));
        ind_myacc.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Century Gothic", 0, 15)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/recmani.png"))); // NOI18N
        jLabel1.setText("Record Manipulation");

        javax.swing.GroupLayout btn_rec_manipulationLayout = new javax.swing.GroupLayout(btn_rec_manipulation);
        btn_rec_manipulation.setLayout(btn_rec_manipulationLayout);
        btn_rec_manipulationLayout.setHorizontalGroup(
            btn_rec_manipulationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_rec_manipulationLayout.createSequentialGroup()
                .addComponent(ind_myacc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        btn_rec_manipulationLayout.setVerticalGroup(
            btn_rec_manipulationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(ind_myacc, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        btn_sdb.setBackground(new java.awt.Color(77, 16, 135));
        btn_sdb.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_sdbMousePressed(evt);
            }
        });

        ind_myacc3.setOpaque(false);
        ind_myacc3.setPreferredSize(new java.awt.Dimension(3, 31));
        ind_myacc3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Century Gothic", 0, 15)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/dbms.png"))); // NOI18N
        jLabel4.setText("System Database");

        javax.swing.GroupLayout btn_sdbLayout = new javax.swing.GroupLayout(btn_sdb);
        btn_sdb.setLayout(btn_sdbLayout);
        btn_sdbLayout.setHorizontalGroup(
            btn_sdbLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_sdbLayout.createSequentialGroup()
                .addComponent(ind_myacc3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        btn_sdbLayout.setVerticalGroup(
            btn_sdbLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(ind_myacc3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        btn_add_table.setBackground(new java.awt.Color(47, 3, 54));
        btn_add_table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_add_tableMousePressed(evt);
            }
        });

        ind_add_table.setOpaque(false);
        ind_add_table.setPreferredSize(new java.awt.Dimension(3, 31));
        ind_add_table.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/submenu.png"))); // NOI18N
        jLabel5.setText("Address");

        javax.swing.GroupLayout btn_add_tableLayout = new javax.swing.GroupLayout(btn_add_table);
        btn_add_table.setLayout(btn_add_tableLayout);
        btn_add_tableLayout.setHorizontalGroup(
            btn_add_tableLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_add_tableLayout.createSequentialGroup()
                .addComponent(ind_add_table, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(55, 55, 55)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        btn_add_tableLayout.setVerticalGroup(
            btn_add_tableLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(ind_add_table, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        btn_cust_table.setBackground(new java.awt.Color(47, 3, 54));
        btn_cust_table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_cust_tableMousePressed(evt);
            }
        });

        ind_cust_table.setOpaque(false);
        ind_cust_table.setPreferredSize(new java.awt.Dimension(3, 31));
        ind_cust_table.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel6.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/submenu.png"))); // NOI18N
        jLabel6.setText("Customers");

        javax.swing.GroupLayout btn_cust_tableLayout = new javax.swing.GroupLayout(btn_cust_table);
        btn_cust_table.setLayout(btn_cust_tableLayout);
        btn_cust_tableLayout.setHorizontalGroup(
            btn_cust_tableLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_cust_tableLayout.createSequentialGroup()
                .addComponent(ind_cust_table, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        btn_cust_tableLayout.setVerticalGroup(
            btn_cust_tableLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(ind_cust_table, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        btn_acc_table.setBackground(new java.awt.Color(47, 3, 54));
        btn_acc_table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_acc_tableMousePressed(evt);
            }
        });

        ind_acc_table.setOpaque(false);
        ind_acc_table.setPreferredSize(new java.awt.Dimension(3, 31));
        ind_acc_table.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/submenu.png"))); // NOI18N
        jLabel7.setText("Accounts");

        javax.swing.GroupLayout btn_acc_tableLayout = new javax.swing.GroupLayout(btn_acc_table);
        btn_acc_table.setLayout(btn_acc_tableLayout);
        btn_acc_tableLayout.setHorizontalGroup(
            btn_acc_tableLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_acc_tableLayout.createSequentialGroup()
                .addComponent(ind_acc_table, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(54, 54, 54)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        btn_acc_tableLayout.setVerticalGroup(
            btn_acc_tableLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(ind_acc_table, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        btn_balance_table.setBackground(new java.awt.Color(47, 3, 54));
        btn_balance_table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_balance_tableMousePressed(evt);
            }
        });

        ind_balance_table.setOpaque(false);
        ind_balance_table.setPreferredSize(new java.awt.Dimension(3, 31));
        ind_balance_table.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/submenu.png"))); // NOI18N
        jLabel8.setText("Balance");

        javax.swing.GroupLayout btn_balance_tableLayout = new javax.swing.GroupLayout(btn_balance_table);
        btn_balance_table.setLayout(btn_balance_tableLayout);
        btn_balance_tableLayout.setHorizontalGroup(
            btn_balance_tableLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_balance_tableLayout.createSequentialGroup()
                .addComponent(ind_balance_table, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(53, 53, 53)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        btn_balance_tableLayout.setVerticalGroup(
            btn_balance_tableLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(ind_balance_table, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        btn_purchase_table.setBackground(new java.awt.Color(47, 3, 54));
        btn_purchase_table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_purchase_tableMousePressed(evt);
            }
        });

        ind_purchase_table.setOpaque(false);
        ind_purchase_table.setPreferredSize(new java.awt.Dimension(3, 31));
        ind_purchase_table.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/submenu.png"))); // NOI18N
        jLabel9.setText("Purchase");

        javax.swing.GroupLayout btn_purchase_tableLayout = new javax.swing.GroupLayout(btn_purchase_table);
        btn_purchase_table.setLayout(btn_purchase_tableLayout);
        btn_purchase_tableLayout.setHorizontalGroup(
            btn_purchase_tableLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_purchase_tableLayout.createSequentialGroup()
                .addComponent(ind_purchase_table, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(54, 54, 54)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        btn_purchase_tableLayout.setVerticalGroup(
            btn_purchase_tableLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(ind_purchase_table, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        btn_service_table.setBackground(new java.awt.Color(47, 3, 54));
        btn_service_table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_service_tableMousePressed(evt);
            }
        });

        ind_service_table.setOpaque(false);
        ind_service_table.setPreferredSize(new java.awt.Dimension(3, 31));
        ind_service_table.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel11.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/submenu.png"))); // NOI18N
        jLabel11.setText("Services");

        javax.swing.GroupLayout btn_service_tableLayout = new javax.swing.GroupLayout(btn_service_table);
        btn_service_table.setLayout(btn_service_tableLayout);
        btn_service_tableLayout.setHorizontalGroup(
            btn_service_tableLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_service_tableLayout.createSequentialGroup()
                .addComponent(ind_service_table, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(55, 55, 55)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        btn_service_tableLayout.setVerticalGroup(
            btn_service_tableLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(ind_service_table, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        btn_transaction_table.setBackground(new java.awt.Color(47, 3, 54));
        btn_transaction_table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_transaction_tableMousePressed(evt);
            }
        });

        ind_transaction_table.setOpaque(false);
        ind_transaction_table.setPreferredSize(new java.awt.Dimension(3, 31));
        ind_transaction_table.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel10.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/submenu.png"))); // NOI18N
        jLabel10.setText("Transaction");

        javax.swing.GroupLayout btn_transaction_tableLayout = new javax.swing.GroupLayout(btn_transaction_table);
        btn_transaction_table.setLayout(btn_transaction_tableLayout);
        btn_transaction_tableLayout.setHorizontalGroup(
            btn_transaction_tableLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_transaction_tableLayout.createSequentialGroup()
                .addComponent(ind_transaction_table, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(54, 54, 54)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        btn_transaction_tableLayout.setVerticalGroup(
            btn_transaction_tableLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(ind_transaction_table, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        btn_cust_manipulation.setBackground(new java.awt.Color(47, 3, 54));
        btn_cust_manipulation.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_cust_manipulationMousePressed(evt);
            }
        });

        ind_cust_manipulation.setOpaque(false);
        ind_cust_manipulation.setPreferredSize(new java.awt.Dimension(3, 31));
        ind_cust_manipulation.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/submenu.png"))); // NOI18N
        jLabel12.setText("Customers");

        javax.swing.GroupLayout btn_cust_manipulationLayout = new javax.swing.GroupLayout(btn_cust_manipulation);
        btn_cust_manipulation.setLayout(btn_cust_manipulationLayout);
        btn_cust_manipulationLayout.setHorizontalGroup(
            btn_cust_manipulationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_cust_manipulationLayout.createSequentialGroup()
                .addComponent(ind_cust_manipulation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        btn_cust_manipulationLayout.setVerticalGroup(
            btn_cust_manipulationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(ind_cust_manipulation, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        btn_about.setBackground(new java.awt.Color(47, 3, 54));
        btn_about.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_aboutMousePressed(evt);
            }
        });

        ind_about.setOpaque(false);
        ind_about.setPreferredSize(new java.awt.Dimension(3, 31));
        ind_about.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel13.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/submenu.png"))); // NOI18N
        jLabel13.setText("About ");

        javax.swing.GroupLayout btn_aboutLayout = new javax.swing.GroupLayout(btn_about);
        btn_about.setLayout(btn_aboutLayout);
        btn_aboutLayout.setHorizontalGroup(
            btn_aboutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_aboutLayout.createSequentialGroup()
                .addComponent(ind_about, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49)
                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        btn_aboutLayout.setVerticalGroup(
            btn_aboutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(ind_about, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        btn_about1.setBackground(new java.awt.Color(77, 16, 135));
        btn_about1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_about1MousePressed(evt);
            }
        });

        ind_about1.setOpaque(false);
        ind_about1.setPreferredSize(new java.awt.Dimension(3, 31));
        ind_about1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel15.setFont(new java.awt.Font("Century Gothic", 0, 15)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/othersmenu.png"))); // NOI18N
        jLabel15.setText("Others");

        javax.swing.GroupLayout btn_about1Layout = new javax.swing.GroupLayout(btn_about1);
        btn_about1.setLayout(btn_about1Layout);
        btn_about1Layout.setHorizontalGroup(
            btn_about1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_about1Layout.createSequentialGroup()
                .addComponent(ind_about1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        btn_about1Layout.setVerticalGroup(
            btn_about1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(ind_about1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        btn_logout.setBackground(new java.awt.Color(47, 3, 54));
        btn_logout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btn_logoutMousePressed(evt);
            }
        });

        ind_logout.setOpaque(false);
        ind_logout.setPreferredSize(new java.awt.Dimension(3, 31));
        ind_logout.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel14.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/submenu.png"))); // NOI18N
        jLabel14.setText("Log Out");

        javax.swing.GroupLayout btn_logoutLayout = new javax.swing.GroupLayout(btn_logout);
        btn_logout.setLayout(btn_logoutLayout);
        btn_logoutLayout.setHorizontalGroup(
            btn_logoutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(btn_logoutLayout.createSequentialGroup()
                .addComponent(ind_logout, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(52, 52, 52)
                .addComponent(jLabel14)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        btn_logoutLayout.setVerticalGroup(
            btn_logoutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(ind_logout, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jLabel46.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        jLabel46.setForeground(new java.awt.Color(0, 204, 204));
        jLabel46.setText("Smart Banking System");

        date1.setFont(new java.awt.Font("Calibri", 0, 12)); // NOI18N
        date1.setForeground(new java.awt.Color(51, 255, 255));
        date1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);

        time.setFont(new java.awt.Font("Calibri", 0, 12)); // NOI18N
        time.setForeground(new java.awt.Color(51, 255, 255));
        time.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btn_sdb, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btn_rec_manipulation, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btn_add_table, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btn_acc_table, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btn_balance_table, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btn_cust_table, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btn_service_table, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btn_transaction_table, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btn_cust_manipulation, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btn_about, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btn_purchase_table, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btn_about1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btn_logout, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(date1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(time, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel46))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel46, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(date1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(time, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25)
                .addComponent(btn_rec_manipulation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(btn_cust_manipulation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(btn_sdb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(btn_cust_table, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(btn_add_table, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(btn_acc_table, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(btn_balance_table, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(btn_purchase_table, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(btn_service_table, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(btn_transaction_table, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(btn_about1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(btn_about, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(btn_logout, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(144, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 210, 680));

        panelHeader.setBackground(new java.awt.Color(255, 102, 0));
        panelHeader.setPreferredSize(new java.awt.Dimension(561, 30));
        panelHeader.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel44.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/close_icon.png"))); // NOI18N
        jLabel44.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel44MouseClicked(evt);
            }
        });
        panelHeader.add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 0, 20, 30));

        jLabel45.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/minimize_icon.png"))); // NOI18N
        jLabel45.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel45MouseClicked(evt);
            }
        });
        panelHeader.add(jLabel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(1060, 0, -1, 30));

        getContentPane().add(panelHeader, new org.netbeans.lib.awtextra.AbsoluteConstraints(205, 0, 1110, 30));

        jPanel2.setBackground(new java.awt.Color(233, 220, 220));
        jPanel2.setPreferredSize(new java.awt.Dimension(1114, 748));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(233, 220, 220));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 102, 0)));
        jPanel3.setLayout(null);

        jPanel4.setBackground(new java.awt.Color(233, 220, 220));
        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 102)), "Present", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Calibri", 1, 18), new java.awt.Color(255, 102, 0))); // NOI18N

        jLabel16.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel16.setText("Office Line");

        present_house_no.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel17.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel17.setText("House No");

        present_house_line.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        present_add.setColumns(20);
        present_add.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        present_add.setRows(5);
        jScrollPane1.setViewportView(present_add);

        jLabel18.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel18.setText("Post Code");

        present_office_line.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel19.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel19.setText("Address");

        jLabel20.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel20.setText("Home Line");

        present_post_code.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel4Layout.createSequentialGroup()
                            .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(present_office_line, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                            .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(present_house_no, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel4Layout.createSequentialGroup()
                            .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(present_house_line, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel4Layout.createSequentialGroup()
                            .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(present_post_code, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(11, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel19)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(present_house_no, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel20)
                    .addComponent(present_house_line, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(present_office_line, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(present_post_code, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jPanel3.add(jPanel4);
        jPanel4.setBounds(10, 220, 320, 234);

        jPanel6.setBackground(new java.awt.Color(233, 220, 220));
        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 102)), "Parmanent", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Calibri", 1, 18), new java.awt.Color(255, 102, 0))); // NOI18N

        parmanent_office_line.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel21.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel21.setText("House No");

        parmanent_house_line.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel22.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel22.setText("Address");

        jLabel23.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel23.setText("Home Line");

        jLabel24.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel24.setText("Post Code");

        parmanent_add.setColumns(20);
        parmanent_add.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        parmanent_add.setRows(5);
        jScrollPane2.setViewportView(parmanent_add);

        parmanent_post_code.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        parmanent_house_no.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel25.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel25.setText("Office Line");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel6Layout.createSequentialGroup()
                            .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(parmanent_office_line, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                            .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(parmanent_house_no, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel6Layout.createSequentialGroup()
                            .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(parmanent_house_line, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel6Layout.createSequentialGroup()
                            .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(parmanent_post_code, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(11, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel22)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(parmanent_house_no, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel23)
                    .addComponent(parmanent_house_line, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel25)
                    .addComponent(parmanent_office_line, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel24)
                    .addComponent(parmanent_post_code, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.add(jPanel6);
        jPanel6.setBounds(350, 220, 320, 234);

        btnImage.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        btnImage.setForeground(new java.awt.Color(0, 0, 255));
        btnImage.setText("Choose Image");
        btnImage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImageActionPerformed(evt);
            }
        });
        jPanel3.add(btnImage);
        btnImage.setBounds(550, 160, 111, 25);

        javax.swing.GroupLayout jDesktopPane1Layout = new javax.swing.GroupLayout(jDesktopPane1);
        jDesktopPane1.setLayout(jDesktopPane1Layout);
        jDesktopPane1Layout.setHorizontalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lbl_img, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
        );
        jDesktopPane1Layout.setVerticalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lbl_img, javax.swing.GroupLayout.DEFAULT_SIZE, 134, Short.MAX_VALUE)
        );
        jDesktopPane1.setLayer(lbl_img, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jPanel3.add(jDesktopPane1);
        jDesktopPane1.setBounds(550, 20, 111, 134);

        jRadioButton1.setFont(new java.awt.Font("Calibri", 0, 12)); // NOI18N
        jRadioButton1.setForeground(new java.awt.Color(0, 0, 204));
        jRadioButton1.setText("Same as Present");
        jRadioButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton1ActionPerformed(evt);
            }
        });
        jPanel3.add(jRadioButton1);
        jRadioButton1.setBounds(360, 460, 120, 18);

        jPanel5.setBackground(new java.awt.Color(233, 220, 220));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel26.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel26.setText("Age               :");
        jPanel5.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 31, -1, 25));

        phone.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel5.add(phone, new org.netbeans.lib.awtextra.AbsoluteConstraints(101, 95, 130, -1));

        gender.setForeground(new java.awt.Color(236, 240, 241));
        gender.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Male", "Female", "Others" }));
        gender.setSelectedItem(null);
        gender.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                genderActionPerformed(evt);
            }
        });
        jPanel5.add(gender, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 60, 130, -1));

        age.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        age.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ageActionPerformed(evt);
            }
        });
        jPanel5.add(age, new org.netbeans.lib.awtextra.AbsoluteConstraints(101, 33, 130, -1));

        jLabel27.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel27.setText("Email            :");
        jPanel5.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 124, 88, 25));

        name.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel5.add(name, new org.netbeans.lib.awtextra.AbsoluteConstraints(101, 2, 130, -1));

        jLabel28.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel28.setText("Gender        :");
        jPanel5.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 62, 71, 25));

        jLabel29.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel29.setText("Phone          :");
        jPanel5.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 93, 71, 25));

        jLabel30.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel30.setText("Name           :");
        jPanel5.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, -1, 25));

        occ.setForeground(new java.awt.Color(236, 240, 241));
        occ.setSelectedItem(null);
        occ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                occActionPerformed(evt);
            }
        });
        jPanel5.add(occ, new org.netbeans.lib.awtextra.AbsoluteConstraints(101, 155, 130, -1));

        jLabel31.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel31.setText("Occupation :");
        jPanel5.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 156, -1, -1));

        mail.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel5.add(mail, new org.netbeans.lib.awtextra.AbsoluteConstraints(101, 124, 130, -1));

        jPanel3.add(jPanel5);
        jPanel5.setBounds(10, 20, 231, 190);

        jPanel7.setBackground(new java.awt.Color(233, 220, 220));
        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel32.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel32.setText("Password          :");
        jPanel7.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 44, 89, -1));

        acc_name.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel7.add(acc_name, new org.netbeans.lib.awtextra.AbsoluteConstraints(118, 104, 135, -1));

        jLabel33.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel33.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel33.setText("Favourite Pet   :");
        jPanel7.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 138, -1, -1));

        user_name.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel7.add(user_name, new org.netbeans.lib.awtextra.AbsoluteConstraints(118, 11, 135, -1));

        user_pass.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel7.add(user_pass, new org.netbeans.lib.awtextra.AbsoluteConstraints(118, 42, 135, -1));

        jLabel34.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel34.setText("User Name       :");
        jPanel7.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 13, 89, -1));

        jLabel35.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel35.setText("Account Type   :");
        jPanel7.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 75, -1, -1));

        jLabel36.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel36.setText("Account Name :");
        jPanel7.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 106, -1, -1));

        jLabel37.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel37.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel37.setText("Date                   :");
        jPanel7.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 169, -1, -1));

        date.setBackground(new java.awt.Color(255, 255, 255));
        date.setForeground(new java.awt.Color(236, 240, 241));
        date.setDateFormatString("yyyy-MM-dd");
        jPanel7.add(date, new org.netbeans.lib.awtextra.AbsoluteConstraints(118, 166, 135, -1));

        acc_type.setForeground(new java.awt.Color(236, 240, 241));
        acc_type.setSelectedItem(null);
        acc_type.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                acc_typeActionPerformed(evt);
            }
        });
        jPanel7.add(acc_type, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 70, 134, -1));

        fav_pet.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel7.add(fav_pet, new org.netbeans.lib.awtextra.AbsoluteConstraints(118, 135, 135, -1));

        jPanel3.add(jPanel7);
        jPanel7.setBounds(270, 10, 254, 200);

        jPanel2.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 679, 490));

        jTable_Display_Users.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Customer ID", "Name", "Phone", "Age"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable_Display_Users.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable_Display_UsersMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jTable_Display_Users);
        if (jTable_Display_Users.getColumnModel().getColumnCount() > 0) {
            jTable_Display_Users.getColumnModel().getColumn(0).setResizable(false);
            jTable_Display_Users.getColumnModel().getColumn(1).setResizable(false);
            jTable_Display_Users.getColumnModel().getColumn(2).setResizable(false);
            jTable_Display_Users.getColumnModel().getColumn(3).setResizable(false);
        }

        jPanel2.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 0, 410, 650));

        jPanel8.setBackground(new java.awt.Color(47, 3, 54));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Calibri", 0, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Customers Directory");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(457, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
        );

        jPanel2.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 690, 40));

        jPanel9.setBackground(new java.awt.Color(204, 204, 204));
        jPanel9.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, new java.awt.Color(204, 255, 255), null, null), "Tools", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Calibri", 1, 18), new java.awt.Color(0, 0, 51))); // NOI18N

        insert.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Add_16x16.png"))); // NOI18N
        insert.setText("Insert");
        insert.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                insertActionPerformed(evt);
            }
        });

        update.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Refresh_16x16.png"))); // NOI18N
        update.setText("Update");
        update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateActionPerformed(evt);
            }
        });

        delete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Delete_16x16.png"))); // NOI18N
        delete.setText("Delete");
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });

        clear.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Clear-icon.png"))); // NOI18N
        clear.setText("Clear");
        clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearActionPerformed(evt);
            }
        });

        next.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Actions-go-next-view-icon.png"))); // NOI18N
        next.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextActionPerformed(evt);
            }
        });

        last.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Actions-go-last-view-icon.png"))); // NOI18N
        last.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lastActionPerformed(evt);
            }
        });

        first.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Actions-go-first-view-icon.png"))); // NOI18N
        first.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                firstActionPerformed(evt);
            }
        });

        previous.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Actions-go-previous-view-icon.png"))); // NOI18N
        previous.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                previousActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addComponent(insert)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(update)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(delete)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(clear)
                .addGap(85, 85, 85)
                .addComponent(first, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(previous, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(next, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(last, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(54, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(last, javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(insert)
                            .addComponent(update)
                            .addComponent(delete)
                            .addComponent(clear)
                            .addComponent(next)))
                    .addComponent(previous, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(first, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        jPanel2.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 570, 679, 80));

        jPanel10.setBackground(new java.awt.Color(233, 220, 220));

        search.setForeground(new java.awt.Color(204, 204, 204));
        search.setText("Search by name here");
        search.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        search.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                searchFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                searchFocusLost(evt);
            }
        });
        search.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                searchKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                searchKeyTyped(evt);
            }
        });

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Actions-page-zoom-icon.png"))); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        hidelvl.setForeground(new java.awt.Color(233, 220, 220));

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(hidelvl, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 373, Short.MAX_VALUE)
                .addComponent(search, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton1))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addGap(0, 7, Short.MAX_VALUE)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(search, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(hidelvl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 679, 30));

        jTabbedPane2.addTab("tab1", jPanel2);

        jPanel12.setBackground(new java.awt.Color(47, 3, 54));

        jLabel3.setBackground(new java.awt.Color(252, 204, 140));
        jLabel3.setFont(new java.awt.Font("Calibri", 0, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Customers");

        search1.setForeground(new java.awt.Color(204, 204, 204));
        search1.setText("Search by name here");
        search1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 0)));
        search1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                search1FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                search1FocusLost(evt);
            }
        });
        search1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                search1ActionPerformed(evt);
            }
        });
        search1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                search1KeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                search1KeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                search1KeyTyped(evt);
            }
        });

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Actions-page-zoom-icon.png"))); // NOI18N
        jButton2.setBorder(null);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(search1, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(search1)
                    .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        Panel2_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Customer Type Code", "Name", "Age", "Gender", "Phone", "Mail", "User ID", "Password", "Image", "SQ Ans"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane4.setViewportView(Panel2_table);
        if (Panel2_table.getColumnModel().getColumnCount() > 0) {
            Panel2_table.getColumnModel().getColumn(0).setResizable(false);
            Panel2_table.getColumnModel().getColumn(2).setResizable(false);
            Panel2_table.getColumnModel().getColumn(3).setResizable(false);
            Panel2_table.getColumnModel().getColumn(4).setResizable(false);
            Panel2_table.getColumnModel().getColumn(5).setResizable(false);
            Panel2_table.getColumnModel().getColumn(6).setResizable(false);
            Panel2_table.getColumnModel().getColumn(7).setResizable(false);
            Panel2_table.getColumnModel().getColumn(8).setResizable(false);
            Panel2_table.getColumnModel().getColumn(9).setResizable(false);
            Panel2_table.getColumnModel().getColumn(10).setResizable(false);
        }

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 1095, Short.MAX_VALUE)
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 606, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("tab2", jPanel11);

        jPanel14.setBackground(new java.awt.Color(47, 3, 54));

        jLabel38.setBackground(new java.awt.Color(252, 204, 140));
        jLabel38.setFont(new java.awt.Font("Calibri", 0, 24)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(255, 255, 255));
        jLabel38.setText("Address Directory");

        search2.setForeground(new java.awt.Color(204, 204, 204));
        search2.setText("Search by name here");
        search2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 0)));
        search2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                search2FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                search2FocusLost(evt);
            }
        });
        search2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                search2ActionPerformed(evt);
            }
        });
        search2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                search2KeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                search2KeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                search2KeyTyped(evt);
            }
        });

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Actions-page-zoom-icon.png"))); // NOI18N
        jButton3.setBorder(null);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(search2, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(search2)
                    .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        Panel_Table3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Address ID", "Present Address", "House", "House Line", "Office Line", "Post Code", "Parmanent Address", "House", "House Line", "Office Line", "Post Code"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane5.setViewportView(Panel_Table3);
        if (Panel_Table3.getColumnModel().getColumnCount() > 0) {
            Panel_Table3.getColumnModel().getColumn(0).setResizable(false);
            Panel_Table3.getColumnModel().getColumn(1).setResizable(false);
            Panel_Table3.getColumnModel().getColumn(3).setResizable(false);
            Panel_Table3.getColumnModel().getColumn(4).setResizable(false);
            Panel_Table3.getColumnModel().getColumn(5).setResizable(false);
            Panel_Table3.getColumnModel().getColumn(6).setResizable(false);
            Panel_Table3.getColumnModel().getColumn(8).setResizable(false);
            Panel_Table3.getColumnModel().getColumn(9).setResizable(false);
            Panel_Table3.getColumnModel().getColumn(10).setResizable(false);
            Panel_Table3.getColumnModel().getColumn(11).setResizable(false);
        }

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 1095, Short.MAX_VALUE)
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 606, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("tab3", jPanel13);

        jPanel16.setBackground(new java.awt.Color(47, 3, 54));

        jLabel39.setBackground(new java.awt.Color(252, 204, 140));
        jLabel39.setFont(new java.awt.Font("Calibri", 0, 24)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(255, 255, 255));
        jLabel39.setText("Accounts");

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel39, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(857, Short.MAX_VALUE))
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addComponent(jLabel39, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Account ID", "Account Type Code", "Account Name", "Account Opening"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane6.setViewportView(jTable2);
        if (jTable2.getColumnModel().getColumnCount() > 0) {
            jTable2.getColumnModel().getColumn(0).setResizable(false);
            jTable2.getColumnModel().getColumn(1).setResizable(false);
            jTable2.getColumnModel().getColumn(2).setResizable(false);
            jTable2.getColumnModel().getColumn(3).setResizable(false);
            jTable2.getColumnModel().getColumn(4).setResizable(false);
        }

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jScrollPane6)
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 606, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("tab4", jPanel15);

        jPanel18.setBackground(new java.awt.Color(47, 3, 54));

        jLabel40.setBackground(new java.awt.Color(252, 204, 140));
        jLabel40.setFont(new java.awt.Font("Calibri", 0, 24)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(255, 255, 255));
        jLabel40.setText("Balance History");

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(857, Short.MAX_VALUE))
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        Panel4_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Account ID", "Net Balance", "Withdrawable"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane7.setViewportView(Panel4_table);
        if (Panel4_table.getColumnModel().getColumnCount() > 0) {
            Panel4_table.getColumnModel().getColumn(0).setResizable(false);
            Panel4_table.getColumnModel().getColumn(2).setResizable(false);
        }

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jScrollPane7)
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 606, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("tab5", jPanel17);

        jPanel20.setBackground(new java.awt.Color(47, 3, 54));

        jLabel41.setBackground(new java.awt.Color(252, 204, 140));
        jLabel41.setFont(new java.awt.Font("Calibri", 0, 24)); // NOI18N
        jLabel41.setForeground(new java.awt.Color(255, 255, 255));
        jLabel41.setText("Purchases");

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(857, Short.MAX_VALUE))
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        Panel5_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Purchase ID", "Service Code", "Purcchase Date", "Quantity", "Total Purchase"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane8.setViewportView(Panel5_table);
        if (Panel5_table.getColumnModel().getColumnCount() > 0) {
            Panel5_table.getColumnModel().getColumn(0).setResizable(false);
            Panel5_table.getColumnModel().getColumn(1).setResizable(false);
            Panel5_table.getColumnModel().getColumn(2).setResizable(false);
            Panel5_table.getColumnModel().getColumn(3).setResizable(false);
            Panel5_table.getColumnModel().getColumn(4).setResizable(false);
            Panel5_table.getColumnModel().getColumn(5).setResizable(false);
        }

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jScrollPane8)
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addComponent(jPanel20, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.DEFAULT_SIZE, 606, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("tab6", jPanel19);

        jPanel22.setBackground(new java.awt.Color(47, 3, 54));

        jLabel42.setBackground(new java.awt.Color(252, 204, 140));
        jLabel42.setFont(new java.awt.Font("Calibri", 0, 24)); // NOI18N
        jLabel42.setForeground(new java.awt.Color(255, 255, 255));
        jLabel42.setText("Services");

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel42, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(857, Short.MAX_VALUE))
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addComponent(jLabel42, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Service Code", "Merchant ID", "Service Rating", "Service Details"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane9.setViewportView(jTable3);
        if (jTable3.getColumnModel().getColumnCount() > 0) {
            jTable3.getColumnModel().getColumn(0).setResizable(false);
            jTable3.getColumnModel().getColumn(1).setResizable(false);
            jTable3.getColumnModel().getColumn(2).setResizable(false);
            jTable3.getColumnModel().getColumn(3).setResizable(false);
        }

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jScrollPane9)
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addComponent(jPanel22, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane9, javax.swing.GroupLayout.DEFAULT_SIZE, 606, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("tab7", jPanel21);

        jPanel24.setBackground(new java.awt.Color(47, 3, 54));

        jLabel43.setBackground(new java.awt.Color(252, 204, 140));
        jLabel43.setFont(new java.awt.Font("Calibri", 0, 24)); // NOI18N
        jLabel43.setForeground(new java.awt.Color(255, 255, 255));
        jLabel43.setText("Transactions");

        search5.setForeground(new java.awt.Color(204, 204, 204));
        search5.setText("Search by name here");
        search5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 0)));
        search5.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                search5FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                search5FocusLost(evt);
            }
        });
        search5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                search5ActionPerformed(evt);
            }
        });
        search5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                search5KeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                search5KeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                search5KeyTyped(evt);
            }
        });

        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Actions-page-zoom-icon.png"))); // NOI18N
        jButton4.setBorder(null);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel24Layout = new javax.swing.GroupLayout(jPanel24);
        jPanel24.setLayout(jPanel24Layout);
        jPanel24Layout.setHorizontalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel43, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(search5, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel24Layout.setVerticalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addComponent(jLabel43, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(search5)
                    .addComponent(jButton4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        Panel3_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Transaction ID", "Account ID", "Purchase ID", "Transaction Date", "Total Transaction", "Available Balance"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane10.setViewportView(Panel3_table);
        if (Panel3_table.getColumnModel().getColumnCount() > 0) {
            Panel3_table.getColumnModel().getColumn(0).setResizable(false);
            Panel3_table.getColumnModel().getColumn(1).setResizable(false);
            Panel3_table.getColumnModel().getColumn(2).setResizable(false);
            Panel3_table.getColumnModel().getColumn(3).setResizable(false);
            Panel3_table.getColumnModel().getColumn(4).setResizable(false);
            Panel3_table.getColumnModel().getColumn(5).setResizable(false);
        }

        jLabel47.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel47.setText("Todays Total Transaction :");

        javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
        jPanel23.setLayout(jPanel23Layout);
        jPanel23Layout.setHorizontalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel24, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jScrollPane10, javax.swing.GroupLayout.DEFAULT_SIZE, 1095, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel23Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel47)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Tsum, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel23Layout.setVerticalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addComponent(jPanel24, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 540, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel47)
                    .addComponent(Tsum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(19, 19, 19))
        );

        jTabbedPane2.addTab("tab8", jPanel23);

        jPanel27.setLayout(null);

        jLabel49.setFont(new java.awt.Font("Calibri", 0, 24)); // NOI18N
        jLabel49.setForeground(new java.awt.Color(0, 0, 51));
        jLabel49.setText("Customers And Online Banking");
        jPanel27.add(jLabel49);
        jLabel49.setBounds(390, 170, 310, 50);

        jLabel50.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel50.setForeground(new java.awt.Color(0, 0, 51));
        jLabel50.setText("Developed By Group-7(Void X)");
        jPanel27.add(jLabel50);
        jLabel50.setBounds(460, 210, 170, 17);

        jLabel51.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/sb.png"))); // NOI18N
        jPanel27.add(jLabel51);
        jLabel51.setBounds(510, 90, 75, 60);

        jSeparator1.setBackground(new java.awt.Color(0, 255, 255));
        jSeparator1.setForeground(new java.awt.Color(102, 255, 255));
        jPanel27.add(jSeparator1);
        jSeparator1.setBounds(370, 232, 360, 0);

        jLabel48.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel48.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/dollar-symbol-1.png"))); // NOI18N
        jPanel27.add(jLabel48);
        jLabel48.setBounds(0, 0, 1090, 640);

        javax.swing.GroupLayout jPanel25Layout = new javax.swing.GroupLayout(jPanel25);
        jPanel25.setLayout(jPanel25Layout);
        jPanel25Layout.setHorizontalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel27, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel25Layout.setVerticalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel25Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel27, javax.swing.GroupLayout.DEFAULT_SIZE, 641, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("tab9", jPanel25);

        javax.swing.GroupLayout jPanel26Layout = new javax.swing.GroupLayout(jPanel26);
        jPanel26.setLayout(jPanel26Layout);
        jPanel26Layout.setHorizontalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1095, Short.MAX_VALUE)
        );
        jPanel26Layout.setVerticalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 652, Short.MAX_VALUE)
        );

        jTabbedPane2.addTab("tab10", jPanel26);

        getContentPane().add(jTabbedPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 0, 1100, 680));

        setSize(new java.awt.Dimension(1310, 680));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_rec_manipulationMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_rec_manipulationMousePressed
      
    }//GEN-LAST:event_btn_rec_manipulationMousePressed

    private void btn_sdbMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_sdbMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_sdbMousePressed
public ArrayList<address> getAddressList()
   {
       con=Connect.ConnectDB();
       ArrayList<address> addList = new ArrayList<address>();

       String query = "SELECT * FROM  address ";
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);
           address addr1;
           while(rs.next())
           {
               //user = new User(rs.getInt("id"),rs.getString("fname"),rs.getString("lname"),rs.getInt("age"));
                addr1 = new address(rs.getInt("Address_id"),rs.getInt("Customer_id"),rs.getString("Present_address"),rs.getString("Pre_house_no") ,rs.getInt("Pre_house_line"),rs.getInt("Pre_office_line"),rs.getString("Pre_post_code"),rs.getString("Parmanent_address"),rs.getString("Par_house_no"),rs.getInt("Par_house_line"),rs.getInt("Par_office_line"),rs.getString("Par_post_code"));
               addList.add(addr1);
           }
       }
 
           catch (Exception e) {
           e.printStackTrace();
       }
       return addList;
   }
   
       
   public void Panel_Table3()
   {
       ArrayList<address> list = getAddressList();
       DefaultTableModel model = (DefaultTableModel)Panel_Table3.getModel();
       Object[] row = new Object[12];
       for(int i = 0; i < list.size(); i++)
       {
         row[0] = list.get(i).getCustomerID();
           row[1] = list.get(i).getAddressId();
           row[2] = list.get(i).getPresentAddress();
           row[3] = list.get(i).getPresentHouseNo();
           row[4] = list.get(i).getPresentHouseLine();
                   row[5] = list.get(i).getPresentOfficeLine();
                   row[6] = list.get(i).getPresentPostCode();
                   row[7] = list.get(i).getParmanentAddress();
                   row[8] = list.get(i).getParmanentHouseNo();
                   row[9] = list.get(i).getParmanentHouseLine();
                   row[10] = list.get(i).getParmanentOfficeLine();
                   row[11] = list.get(i).getParmanentPOstCode();
    model.addRow(row);
       }
    }
    
    
    private void btn_add_tableMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_add_tableMousePressed
         q= new PlaceHolder(search2,"Search by id/name");
         
        DefaultTableModel model=(DefaultTableModel)Panel_Table3.getModel();
        model.setRowCount(0);
        Panel_Table3();
        jLabel1.setFont(new  Font("Centry Gothic",Font.PLAIN,15));
      jLabel4.setFont(new  Font("Centry Gothic",Font.BOLD,15));
      jLabel15.setFont(new  Font("Centry Gothic",Font.PLAIN,15));
        resetColor(btn_cust_manipulation);
        resetColor(btn_cust_table);
        setColor(btn_add_table);
        resetColor(btn_acc_table);
        resetColor(btn_balance_table);
        resetColor(btn_purchase_table);
        resetColor(btn_service_table);
        resetColor(btn_transaction_table);
        resetColor(btn_about);
        resetColor(btn_logout);
        // TODO add your handling code here:
        ind_cust_manipulation.setOpaque(false);
        ind_cust_table.setOpaque(false);
        ind_add_table.setOpaque(true);
        ind_acc_table.setOpaque(false);
        ind_balance_table.setOpaque(false);
        ind_purchase_table.setOpaque(false);
        ind_service_table.setOpaque(false);
        ind_transaction_table.setOpaque(false);
        ind_about.setOpaque(false);
        ind_logout.setOpaque(false);
        jTabbedPane2.setSelectedIndex(2);        // TODO add your handling code here:
    }//GEN-LAST:event_btn_add_tableMousePressed

    private void btn_cust_tableMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_cust_tableMousePressed
r= new PlaceHolder(search1,"Search by id/name");

        DefaultTableModel model=(DefaultTableModel)Panel2_table.getModel();
        model.setRowCount(0);
        Panel2_table();
        jLabel1.setFont(new  Font("Centry Gothic",Font.PLAIN,15));
      jLabel4.setFont(new  Font("Centry Gothic",Font.BOLD,15));
      jLabel15.setFont(new  Font("Centry Gothic",Font.PLAIN,15));
        resetColor(btn_cust_manipulation);
        setColor(btn_cust_table);
        resetColor(btn_add_table);
        resetColor(btn_acc_table);
        resetColor(btn_balance_table);
        resetColor(btn_purchase_table);
        resetColor(btn_service_table);
        resetColor(btn_transaction_table);
        resetColor(btn_about);
        resetColor(btn_logout);
        // TODO add your handling code here:
        ind_cust_manipulation.setOpaque(false);
        ind_cust_table.setOpaque(true);
        ind_add_table.setOpaque(false);
        ind_acc_table.setOpaque(false);
        ind_balance_table.setOpaque(false);
        ind_purchase_table.setOpaque(false);
        ind_service_table.setOpaque(false);
        ind_transaction_table.setOpaque(false);
        ind_about.setOpaque(false);
        ind_logout.setOpaque(false);
        jTabbedPane2.setSelectedIndex(1);

// TODO add your handling code here:
    }//GEN-LAST:event_btn_cust_tableMousePressed

    public ArrayList<accounts> getAccountList()
   {
       con=Connect.ConnectDB();
       ArrayList<accounts> accList = new ArrayList<accounts>();

       String query = "SELECT * FROM  accounts ";
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);
           accounts acc1;
           while(rs.next())
           {
               //user = new User(rs.getInt("id"),rs.getString("fname"),rs.getString("lname"),rs.getInt("age"));
                acc1 = new accounts(rs.getInt("Account_id"),rs.getInt("Account_type_code"),rs.getInt("Customer_id"),rs.getString("Account_name") ,rs.getDate("Account_opening"));
               accList.add(acc1);
           }
       }
 
           catch (Exception e) {
           e.printStackTrace();
       }
       return accList;
   }
   
       
   public void jTable2()
   {
       ArrayList<accounts> list = getAccountList();
       DefaultTableModel model = (DefaultTableModel)jTable2.getModel();
       Object[] row = new Object[5];
       for(int i = 0; i < list.size(); i++)
       {
         row[0] = list.get(i).getCustomerID();
           row[1] = list.get(i).getAccountId();
           row[2] = list.get(i).getAccountTypeCode();
           row[3] = list.get(i).getAccountName();
           row[4] = list.get(i).getAccountOpening();
                  
    model.addRow(row);
       }
    }
    private void btn_acc_tableMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_acc_tableMousePressed
 DefaultTableModel model=(DefaultTableModel)jTable2.getModel();
        model.setRowCount(0);
        jTable2();
        jLabel1.setFont(new  Font("Centry Gothic",Font.PLAIN,15));
      jLabel4.setFont(new  Font("Centry Gothic",Font.BOLD,15));
      jLabel15.setFont(new  Font("Centry Gothic",Font.PLAIN,15));
        resetColor(btn_cust_manipulation);
        resetColor(btn_cust_table);
        resetColor(btn_add_table);
        setColor(btn_acc_table);
        resetColor(btn_balance_table);
        resetColor(btn_purchase_table);
        resetColor(btn_service_table);
        resetColor(btn_transaction_table);
        resetColor(btn_about);
        resetColor(btn_logout);
        // TODO add your handling code here:
        ind_cust_manipulation.setOpaque(false);
        ind_cust_table.setOpaque(false);
        ind_add_table.setOpaque(false);
        ind_acc_table.setOpaque(true);
        ind_balance_table.setOpaque(false);
        ind_purchase_table.setOpaque(false);
        ind_service_table.setOpaque(false);
        ind_transaction_table.setOpaque(false);
        ind_about.setOpaque(false);
        ind_logout.setOpaque(false);
        jTabbedPane2.setSelectedIndex(3);

        // TODO add your handling code here:
    }//GEN-LAST:event_btn_acc_tableMousePressed
     public ArrayList<balance> getBalanceList()
   {
       con=Connect.ConnectDB();
       ArrayList<balance> balanceList = new ArrayList<balance>();

       String query = "SELECT * FROM  balance_history ";
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);
           balance balance1;
           while(rs.next())
           {
               //user = new User(rs.getInt("id"),rs.getString("fname"),rs.getString("lname"),rs.getInt("age"));
                balance1 = new balance(rs.getInt("Account_id"),rs.getInt("Current_balance"),rs.getInt("Withdrawable"));
               balanceList.add(balance1);
           }
       }
 
           catch (Exception e) {
           e.printStackTrace();
       }
       return balanceList;
   }
   
       
   public void Panel4_table()
   {
       ArrayList<balance> list = getBalanceList();
       DefaultTableModel model = (DefaultTableModel)Panel4_table.getModel();
       Object[] row = new Object[3];
       for(int i = 0; i < list.size(); i++)
       {
         row[0] = list.get(i).getAccountId();
           row[1] = list.get(i).getCurrentBalance();
           row[2] = list.get(i).getWithdrawable();           
    model.addRow(row);
       }
    }
    
    
    private void btn_balance_tableMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_balance_tableMousePressed
 DefaultTableModel model=(DefaultTableModel)Panel4_table.getModel();
        model.setRowCount(0);
        Panel4_table();
jLabel1.setFont(new  Font("Centry Gothic",Font.PLAIN,15));
      jLabel4.setFont(new  Font("Centry Gothic",Font.BOLD,15));
      jLabel15.setFont(new  Font("Centry Gothic",Font.PLAIN,15));
        resetColor(btn_cust_manipulation);
        resetColor(btn_cust_table);
        resetColor(btn_add_table);
        resetColor(btn_acc_table);
        setColor(btn_balance_table);
        resetColor(btn_purchase_table);
        resetColor(btn_service_table);
        resetColor(btn_transaction_table);
        resetColor(btn_about);
        resetColor(btn_logout);
        // TODO add your handling code here:
        ind_cust_manipulation.setOpaque(false);
        ind_cust_table.setOpaque(false);
        ind_add_table.setOpaque(false);
        ind_acc_table.setOpaque(false);
        ind_balance_table.setOpaque(true);
        ind_purchase_table.setOpaque(false);
        ind_service_table.setOpaque(false);
        ind_transaction_table.setOpaque(false);
        ind_about.setOpaque(false);
        ind_logout.setOpaque(false);
        jTabbedPane2.setSelectedIndex(4);
       // TODO add your handling code here:
    }//GEN-LAST:event_btn_balance_tableMousePressed

  public ArrayList<purchase> getPurchaseList()
   {
       con=Connect.ConnectDB();
       ArrayList<purchase> purchaseList = new ArrayList<purchase>();

       String query = "SELECT * FROM  customer_purchase ";
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);
           purchase purchase1;
           while(rs.next())
           {
               //user = new User(rs.getInt("id"),rs.getString("fname"),rs.getString("lname"),rs.getInt("age"));
                purchase1 = new purchase(rs.getInt("Purchase_id"),rs.getInt("Customer_id"),rs.getInt("Service_code"),rs.getDate("Purchase_date"),rs.getInt("Quantity"),rs.getInt("Total_amount"));
               purchaseList.add(purchase1);
           }
       }
 
           catch (Exception e) {
           e.printStackTrace();
       }
       return purchaseList;
   }
   
       
   public void Panel5_table()
   {
       ArrayList<purchase> list = getPurchaseList();
       DefaultTableModel model = (DefaultTableModel)Panel5_table.getModel();
       Object[] row = new Object[6];
       for(int i = 0; i < list.size(); i++)
       {
         row[0] = list.get(i).getCustomerID();
           row[1] = list.get(i).getPurchaseId();
           row[2] = list.get(i).getServiceCode();
           row[3] = list.get(i).getPurchaseDate();
           row[4] = list.get(i).getQuantity();
                   row[5] = list.get(i).getTotalAmount();          
    model.addRow(row);
       }
    }   
    
    private void btn_purchase_tableMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_purchase_tableMousePressed
 DefaultTableModel model=(DefaultTableModel)Panel5_table.getModel();
        model.setRowCount(0);
        Panel5_table();
        jLabel1.setFont(new  Font("Centry Gothic",Font.PLAIN,15));
      jLabel4.setFont(new  Font("Centry Gothic",Font.BOLD,15));
      jLabel15.setFont(new  Font("Centry Gothic",Font.PLAIN,15));
        resetColor(btn_cust_manipulation);
        resetColor(btn_cust_table);
        resetColor(btn_add_table);
        resetColor(btn_acc_table);
        resetColor(btn_balance_table);
        setColor(btn_purchase_table);
        resetColor(btn_service_table);
        resetColor(btn_transaction_table);
        resetColor(btn_about);
        resetColor(btn_logout);
        // TODO add your handling code here:
        ind_cust_manipulation.setOpaque(false);
        ind_cust_table.setOpaque(false);
        ind_add_table.setOpaque(false);
        ind_acc_table.setOpaque(false);
        ind_balance_table.setOpaque(false);
        ind_purchase_table.setOpaque(true);
        ind_service_table.setOpaque(false);
        ind_transaction_table.setOpaque(false);
        ind_about.setOpaque(false);
        ind_logout.setOpaque(false);
        jTabbedPane2.setSelectedIndex(5);        // TODO add your handling code here:
    }//GEN-LAST:event_btn_purchase_tableMousePressed

     public ArrayList<transactions> getTransactionList()
   {
       con=Connect.ConnectDB();
       ArrayList<transactions> transactionList = new ArrayList<transactions>();

       String query = "SELECT * FROM  transactions ";
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);
           transactions tran1;
           while(rs.next())
           {
               //user = new User(rs.getInt("id"),rs.getString("fname"),rs.getString("lname"),rs.getInt("age"));
                tran1 = new transactions(rs.getInt("Transaction_id"),rs.getInt("Account_id"),rs.getInt("Purchase_id"),rs.getDate("Transaction_date") ,rs.getInt("Total_transaction"),rs.getInt("Available_balance"));
               transactionList.add(tran1);
           }
       }
 
           catch (Exception e) {
           e.printStackTrace();
       }
       return transactionList;
   }
   
       
   public void Panel3_table()
   {
       ArrayList<transactions> list = getTransactionList();
       DefaultTableModel model = (DefaultTableModel)Panel3_table.getModel();
       Object[] row = new Object[6];
       for(int i = 0; i < list.size(); i++)
       {
         row[0] = list.get(i).getTransactionID();
           row[1] = list.get(i).getAccountID();
           row[2] = list.get(i).getPurchaseID();
           row[3] = list.get(i).getTransactionDate();
           row[4] = list.get(i).getTotalTransaction();
           row[5] = list.get(i).getAvailableBalance();
                  
    model.addRow(row);
       }
    }   
    
    private void btn_transaction_tableMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_transaction_tableMousePressed
t= new PlaceHolder(search5,"Search here");
        
        
        DefaultTableModel model=(DefaultTableModel)Panel3_table.getModel();
        model.setRowCount(0);
              Panel3_table();
              
              getSum();
                      
                      
        jLabel1.setFont(new  Font("Centry Gothic",Font.PLAIN,15));
      jLabel4.setFont(new  Font("Centry Gothic",Font.BOLD,15));
      jLabel15.setFont(new  Font("Centry Gothic",Font.PLAIN,15));
        resetColor(btn_cust_manipulation);
        resetColor(btn_cust_table);
        resetColor(btn_add_table);
        resetColor(btn_acc_table);
        resetColor(btn_balance_table);
        resetColor(btn_purchase_table);
        resetColor(btn_service_table);
        setColor(btn_transaction_table);
        resetColor(btn_about);
        resetColor(btn_logout);
        // TODO add your handling code here:
        ind_cust_manipulation.setOpaque(false);
        ind_cust_table.setOpaque(false);
        ind_add_table.setOpaque(false);
        ind_acc_table.setOpaque(false);
        ind_balance_table.setOpaque(false);
        ind_purchase_table.setOpaque(false);
        ind_service_table.setOpaque(false);
        ind_transaction_table.setOpaque(true);
        ind_about.setOpaque(false);
        ind_logout.setOpaque(false);
        jTabbedPane2.setSelectedIndex(7);        // TODO add your handling code here:
    }//GEN-LAST:event_btn_transaction_tableMousePressed

     public ArrayList<services> getServiceList()
   {
       con=Connect.ConnectDB();
       ArrayList<services> serviceList = new ArrayList<services>();

       String query = "SELECT * FROM  product_and_services ";
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);
           services ser1;
           while(rs.next())
           {
                ser1 = new services(rs.getInt("Service_code"),rs.getInt("Merchant_id"),rs.getInt("Service_rating"),rs.getString("Service_details"));
           serviceList.add(ser1);
           }
           
       }
 
           catch (Exception e) {
           e.printStackTrace();
       }
       return serviceList;
   }
   
       
   public void jTable3()
   {
       ArrayList<services> list = getServiceList();
       DefaultTableModel model = (DefaultTableModel)jTable3.getModel();
       Object[] row = new Object[4];
       for(int i = 0; i < list.size(); i++)
       {
         row[0] = list.get(i).getServiceCode();
           row[1] = list.get(i).getMerchantID();
           row[2] = list.get(i).getServiceRating();
           row[3] = list.get(i).getServiceDetails();
                  
    model.addRow(row);
       }
    }   
    
    private void btn_service_tableMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_service_tableMousePressed
 DefaultTableModel model=(DefaultTableModel)jTable3.getModel();
        model.setRowCount(0);
        jTable3();
        jLabel1.setFont(new  Font("Centry Gothic",Font.PLAIN,15));
      jLabel4.setFont(new  Font("Centry Gothic",Font.BOLD,15));
      jLabel15.setFont(new  Font("Centry Gothic",Font.PLAIN,15));
        resetColor(btn_cust_manipulation);
        resetColor(btn_cust_table);
        resetColor(btn_add_table);
        resetColor(btn_acc_table);
        resetColor(btn_balance_table);
        resetColor(btn_purchase_table);
        setColor(btn_service_table);
        resetColor(btn_transaction_table);
        resetColor(btn_about);
        resetColor(btn_logout);
        // TODO add your handling code here:
        ind_cust_manipulation.setOpaque(false);
        ind_cust_table.setOpaque(false);
        ind_add_table.setOpaque(false);
        ind_acc_table.setOpaque(false);
        ind_balance_table.setOpaque(false);
        ind_purchase_table.setOpaque(false);
        ind_service_table.setOpaque(true);
        ind_transaction_table.setOpaque(false);
        ind_about.setOpaque(false);
        ind_logout.setOpaque(false);
        jTabbedPane2.setSelectedIndex(6);          // TODO add your handling code here:
    }//GEN-LAST:event_btn_service_tableMousePressed
 public ArrayList<customer> getCustomerList()
   {
       con=Connect.ConnectDB();
       ArrayList<customer> custList = new ArrayList<customer>();

       String query = "SELECT * FROM  customers ";
       Statement st;
       ResultSet rs;
       
       try {
           st = con.createStatement();
           rs = st.executeQuery(query);
           customer cust1;
           while(rs.next())
           {
               //user = new User(rs.getInt("id"),rs.getString("fname"),rs.getString("lname"),rs.getInt("age"));
                cust1 = new customer(rs.getInt("Customer_id"),rs.getString("Customer_type_code"),rs.getString("Customer_name"),rs.getInt("Age") ,rs.getString("Gender"),rs.getString("Customer_phone"),rs.getString("Customer_mail"),rs.getString("User_id"),rs.getString("User_pass"),rs.getBytes("Image"),rs.getString("Security_question"));
               custList.add(cust1);
           }
       }
 
           catch (Exception e) {
           e.printStackTrace();
       }
       return custList;
   }
     
   public void Panel2_table()
   {
       ArrayList<customer> list = getCustomerList();
       DefaultTableModel model = (DefaultTableModel)Panel2_table.getModel();
       Object[] row = new Object[11];
       for(int i = 0; i < list.size(); i++)
       {
           row[0] = list.get(i).getCustomerId();
           row[1] = list.get(i).getCustomerType();
           row[2] = list.get(i).getCustomerName();
           row[3] = list.get(i).getAge();
           row[4] = list.get(i).getGender();
                   row[5] = list.get(i).getCustomerphone();
                   row[6] = list.get(i).getCustomermail();
                   row[7] = list.get(i).getUserId();
                   row[8] = list.get(i).getUserPass();
                   row[9] = list.get(i).getImage();
                   row[10] = list.get(i).getSecurityQuestion();
    model.addRow(row);
       }
    }

    private void btn_cust_manipulationMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_cust_manipulationMousePressed
      p= new PlaceHolder(search,"Search by id/name");
        jLabel1.setFont(new  Font("Centry Gothic",Font.BOLD,15));
      jLabel4.setFont(new  Font("Centry Gothic",Font.PLAIN,15));
      jLabel15.setFont(new  Font("Centry Gothic",Font.PLAIN,15));
        setColor(btn_cust_manipulation);
        resetColor(btn_cust_table);
        resetColor(btn_add_table);
        resetColor(btn_acc_table);
        resetColor(btn_balance_table);
        resetColor(btn_purchase_table);
        resetColor(btn_service_table);
        resetColor(btn_transaction_table);
        resetColor(btn_about);
        resetColor(btn_logout);
        // TODO add your handling code here:
        ind_cust_manipulation.setOpaque(true);
        ind_cust_table.setOpaque(false);
        ind_add_table.setOpaque(false);
        ind_acc_table.setOpaque(false);
        ind_balance_table.setOpaque(false);
        ind_purchase_table.setOpaque(false);
        ind_service_table.setOpaque(false);
        ind_transaction_table.setOpaque(false);
        ind_about.setOpaque(false);
        ind_logout.setOpaque(false);
        jTabbedPane2.setSelectedIndex(0);
       // TODO add your handling code here:
    }//GEN-LAST:event_btn_cust_manipulationMousePressed

    private void btn_aboutMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_aboutMousePressed
jLabel1.setFont(new  Font("Centry Gothic",Font.PLAIN,15));
      jLabel4.setFont(new  Font("Centry Gothic",Font.PLAIN,15));
      jLabel15.setFont(new  Font("Centry Gothic",Font.BOLD,15));
        resetColor(btn_cust_manipulation);
        resetColor(btn_cust_table);
        resetColor(btn_add_table);
        resetColor(btn_acc_table);
        resetColor(btn_balance_table);
        resetColor(btn_purchase_table);
        resetColor(btn_service_table);
        resetColor(btn_transaction_table);
        setColor(btn_about);
        resetColor(btn_logout);
        // TODO add your handling code here:
        ind_cust_manipulation.setOpaque(false);
        ind_cust_table.setOpaque(false);
        ind_add_table.setOpaque(false);
        ind_acc_table.setOpaque(false);
        ind_balance_table.setOpaque(false);
        ind_purchase_table.setOpaque(false);
        ind_service_table.setOpaque(false);
        ind_transaction_table.setOpaque(false);
        ind_about.setOpaque(true);
        ind_logout.setOpaque(false);
        jTabbedPane2.setSelectedIndex(8);        // TODO add your handling code here:
    }//GEN-LAST:event_btn_aboutMousePressed

    private void btn_logoutMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_logoutMousePressed
jLabel1.setFont(new  Font("Centry Gothic",Font.PLAIN,15));
      jLabel4.setFont(new  Font("Centry Gothic",Font.PLAIN,15));
      jLabel15.setFont(new  Font("Centry Gothic",Font.BOLD,15));
        resetColor(btn_cust_manipulation);
        resetColor(btn_cust_table);
        resetColor(btn_add_table);
        resetColor(btn_acc_table);
        resetColor(btn_balance_table);
        resetColor(btn_purchase_table);
        resetColor(btn_service_table);
        resetColor(btn_transaction_table);
        resetColor(btn_about);
        setColor(btn_logout);
        // TODO add your handling code here:
        ind_cust_manipulation.setOpaque(false);
        ind_cust_table.setOpaque(false);
        ind_add_table.setOpaque(false);
        ind_acc_table.setOpaque(false);
        ind_balance_table.setOpaque(false);
        ind_purchase_table.setOpaque(false);
        ind_service_table.setOpaque(false);
        ind_transaction_table.setOpaque(false);
        ind_about.setOpaque(false);
        ind_logout.setOpaque(true);
        jTabbedPane2.setSelectedIndex(9);  
        JOptionPane.showMessageDialog( null, "Loged Out !","Warning", JOptionPane.WARNING_MESSAGE);
        System.exit(0);
        
        
// TODO add your handling code here:
    }//GEN-LAST:event_btn_logoutMousePressed

    private void btn_about1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_about1MousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_about1MousePressed

    private void jLabel44MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel44MouseClicked
        System.exit(0);        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel44MouseClicked

    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed
        try{
        con=Connect.ConnectDB();
       // int i = jTable_Display_Users.getSelectedRow();
          // String x=jTable_Display_Users.getModel().getValueAt(i,0).toString();

        String query = "DELETE FROM customers WHERE customer_id = '"+hidelvl.getText()+"'"; 
        executeSQlQuery(query, "Deleted");
      
        DefaultTableModel model = (DefaultTableModel)jTable_Display_Users.getModel();
            model.setRowCount(0);
            Show_Users_In_JTable();
            
              name.setText("");
         age.setText("");
         gender.setSelectedIndex(-1);
         phone.setText("");
        mail.setText("");
       occ.setSelectedIndex(-1);
         user_name.setText("");
         user_pass.setText("");
         acc_type.setSelectedIndex(-1);
         acc_name.setText("");
         fav_pet.setText("");
         date.setDate(null);
         lbl_img.setIcon(null);
         jRadioButton1.setSelected(false);
         hidelvl.setText("");
               parmanent_add.setText("");
               present_add.setText("");
               parmanent_house_no.setText("");
               present_house_no.setText("");
               parmanent_house_line.setText("");
               present_house_line.setText("");
               parmanent_office_line.setText("");
               present_office_line.setText("");
               parmanent_post_code.setText("");
               present_post_code.setText("");
               search.setText("");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(this,e);
            
            
        }
    }//GEN-LAST:event_deleteActionPerformed

    private void acc_typeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_acc_typeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_acc_typeActionPerformed

    private void occActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_occActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_occActionPerformed

    private void ageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ageActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ageActionPerformed

    private void genderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_genderActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_genderActionPerformed

    private void jRadioButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton1ActionPerformed
         parmanent_add.setText(present_add.getText());
        parmanent_house_no.setText(present_house_no.getText());
        parmanent_house_line.setText(present_house_line.getText());
        parmanent_office_line.setText(present_office_line.getText());
        parmanent_post_code.setText(present_post_code.getText());
    }//GEN-LAST:event_jRadioButton1ActionPerformed

    private void btnImageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImageActionPerformed
        JFileChooser chooser=new JFileChooser();
        chooser.showOpenDialog(null);
        File f= chooser.getSelectedFile();
        filename=f.getAbsolutePath();
        //jTextField1.setText(filename);
        ImageIcon imageIcon=new ImageIcon(new ImageIcon(filename).getImage().getScaledInstance(lbl_img.getWidth(),lbl_img.getHeight(),Image.SCALE_SMOOTH));
        lbl_img.setIcon(imageIcon);
        try{
            File image = new File(filename);
            FileInputStream fis=new FileInputStream(image);
            ByteArrayOutputStream bos=new ByteArrayOutputStream();
            byte[] buf=new byte[1024];
            for(int readNum;(readNum=fis.read(buf))!=-1;){
                bos.write(buf,0,readNum);
            }
            p_image= bos.toByteArray();
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_btnImageActionPerformed

    private void searchFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_searchFocusGained
search.setText("");
search.setForeground(Color.BLACK);
    }//GEN-LAST:event_searchFocusGained

    private void searchFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_searchFocusLost

    }//GEN-LAST:event_searchFocusLost

    private void searchKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchKeyTyped

    }//GEN-LAST:event_searchKeyTyped

    private void searchKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchKeyPressed
 // TODO add your handling code here:
    }//GEN-LAST:event_searchKeyPressed

    private void previousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_previousActionPerformed
if(!hidelvl.getText().equals(""))
{       
    String z3=hidelvl.getText();

int x= Integer.parseInt(z3);
x=x-1;
if(x!=0){
    
      con=Connect.ConnectDB();
        try{
    Image image;
    hidelvl.setText(Integer.toString(x));
            //DefaultTableModel model;
        String query5= "select * from customers where Customer_id= '" +x+ "'";
        pst=con.prepareStatement(query5);
        rs= pst.executeQuery();
        if(rs.next()){
            String m = rs.getString("Customer_name").trim();
            String ag = rs.getString("Age").trim();
            String ph = rs.getString("Customer_phone").trim();
            String ge = rs.getString("Gender").trim();
            String cusmail = rs.getString("Customer_mail").trim();
            String uid = rs.getString("User_id").trim();
            String upass = rs.getString("User_pass").trim();
            String type = rs.getString("Customer_type_code").trim();
            String ans = rs.getString("Security_question").trim();
             imageBytes=rs.getBytes("Image");
            image=getToolkit().createImage(imageBytes);
            ImageIcon icon = new ImageIcon(image);
            Image im=icon.getImage();
            Image myImage=im.getScaledInstance(lbl_img.getWidth(), lbl_img.getHeight(), Image.SCALE_SMOOTH);
            ImageIcon newicon = new ImageIcon(myImage);
            lbl_img.setIcon(newicon);
            name.setText(m);
             age.setText(ag);
             phone.setText(ph);
            gender.setSelectedItem(ge);
            mail.setText(cusmail);   
             user_name.setText(uid);
             user_pass.setText(upass);
             fav_pet.setText(ans);
               String query10= "select * from customer_type where Customer_type_code= '" +type+ "'";
                pst=con.prepareStatement(query10);
                rs= pst.executeQuery();
              if(rs.next()){
              String cusype = rs.getString("Customer_type").trim();
             occ.setSelectedItem(cusype);
                 }
        }
        else{
            JOptionPane.showMessageDialog(this, "No Record Exist !", "Error", JOptionPane.ERROR_MESSAGE);
             name.setText("");
         age.setText("");
         gender.setSelectedIndex(-1);
         phone.setText("");
        mail.setText("");
       occ.setSelectedIndex(-1);
         user_name.setText("");
         user_pass.setText("");
         acc_type.setSelectedIndex(-1);
         acc_name.setText("");
         fav_pet.setText("");
         date.setDate(null);
               parmanent_add.setText("");
               present_add.setText("");
               parmanent_house_no.setText("");
               present_house_no.setText("");
               parmanent_house_line.setText("");
               present_house_line.setText("");
               parmanent_office_line.setText("");
               present_office_line.setText("");
               parmanent_post_code.setText("");
               present_post_code.setText("");
              search.setText("");
            return;
        }
       
        
        String query6= "select * from accounts where Customer_id= '" +x+ "'";
        pst=con.prepareStatement(query6);
        rs= pst.executeQuery();
        if(rs.next()){
           String opdate = rs.getString("Account_opening").trim(); 
           String accountname = rs.getString("Account_name").trim(); 
           String accountype = rs.getString("Account_type_code").trim();
           date.setDate(new SimpleDateFormat("yyyy-MM-dd").parse(opdate));
           acc_name.setText(accountname);
           
            String query9= "select * from account_type where Account_type_code= '" +accountype+ "'";
        pst=con.prepareStatement(query9);
        rs= pst.executeQuery();
        if(rs.next()){
           String acctype = rs.getString("Account_type").trim();
           acc_type.setSelectedItem(acctype);
                }
        }
        
        
        String query11= "select * from address where Customer_id= '" +x+ "'";
        pst=con.prepareStatement(query11);
        rs= pst.executeQuery();
        if(rs.next()){
           String a1 = rs.getString("Present_address").trim(); 
           String a2 = rs.getString("Pre_house_no").trim(); 
           String a3 = rs.getString("Pre_house_line").trim(); 
           String a4 = rs.getString("Pre_Office_line").trim(); 
           String a5 = rs.getString("Pre_post_code").trim(); 
           String a6 = rs.getString("Parmanent_address").trim(); 
           String a7 = rs.getString("Par_house_no").trim(); 
           String a8 = rs.getString("Par_house_line").trim();
           String a9 = rs.getString("Par_office_line").trim(); 
           String a10 = rs.getString("Par_post_code").trim();
               parmanent_add.setText(a6);
               present_add.setText(a1);
               parmanent_house_no.setText(a7);
               present_house_no.setText(a2);
               parmanent_house_line.setText(a8);
               present_house_line.setText(a3);
               parmanent_office_line.setText(a9);
               present_office_line.setText(a4);
               parmanent_post_code.setText(a10);
               present_post_code.setText(a5);
        }
   
        }
 
        catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }   
}
}
    }//GEN-LAST:event_previousActionPerformed

    private void formMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseDragged
int coordinateX=evt.getXOnScreen();  
             int coordinateY=evt.getYOnScreen();
             this.setLocation(coordinateX - mouseX, coordinateY - mouseY);        // TODO add your handling code here:
    }//GEN-LAST:event_formMouseDragged

    private void formMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMousePressed
      mouseX=evt.getX();  
      mouseY=evt.getY();        // TODO add your handling code here:
    }//GEN-LAST:event_formMousePressed

    private void insertActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_insertActionPerformed
if(hidelvl.getText().equals("")){
        
        try{
            con=Connect.ConnectDB();
           genC_ID();
           genAccount_ID();
           genAddress_ID();
           if (name.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "Please enter your name !", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (age.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "Please enter your age !", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (gender.getSelectedIndex()==-1) {
            JOptionPane.showMessageDialog(this, "Please enter your gender !", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (phone.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "Please your phone number !", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
          if (mail.getText().equals("")) {
         JOptionPane.showMessageDialog( this, "Please enter your mail !","Error", JOptionPane.ERROR_MESSAGE);
         return;
         }
        if (occ.getSelectedIndex()==-1) {
            JOptionPane.showMessageDialog(this, "Please enter your occupation !", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (user_name.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "Please enter your user name !", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (user_pass.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "Please enter your password !", "Error", JOptionPane.ERROR_MESSAGE);
            return;

        }
        if (acc_type.getSelectedIndex()==-1) {
            JOptionPane.showMessageDialog(this, "Please enter account type !", "Error", JOptionPane.ERROR_MESSAGE);
            return;

        }
        if (acc_name.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "Please enter your account name !", "Error", JOptionPane.ERROR_MESSAGE);
            return;

        }
        if (fav_pet.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "Please enter your favourite pet name !", "Error", JOptionPane.ERROR_MESSAGE);
            return;

        }
        if (date.getDate().equals("")) {
            JOptionPane.showMessageDialog(this, "Please enter date !", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (present_add.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "Please enter your present address !", "Error", JOptionPane.ERROR_MESSAGE);
            return;

        }
        if (present_house_no.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "Please enter your present house no !", "Error", JOptionPane.ERROR_MESSAGE);
            return;

        }
        if (present_house_line.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "Please enter your present home line number !", "Error", JOptionPane.ERROR_MESSAGE);
            return;

        }
        if (present_office_line.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "Please enter your present office line number !", "Error", JOptionPane.ERROR_MESSAGE);
            return;

        }
        if (present_post_code.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "Please enter your present address post code !", "Error", JOptionPane.ERROR_MESSAGE);
            return;

        }
        if (parmanent_add.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "Please enter your parmanent address !", "Error", JOptionPane.ERROR_MESSAGE);
            return;

        }
        if (parmanent_house_no.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "Please enter your parmanent house no !", "Error", JOptionPane.ERROR_MESSAGE);
            return;

        }
        if (parmanent_house_line.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "Please enter your parmanent home line number !", "Error", JOptionPane.ERROR_MESSAGE);
            return;

        }
        if (parmanent_office_line.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "Please enter your parmanent office line number !", "Error", JOptionPane.ERROR_MESSAGE);
            return;

        }
        if (parmanent_post_code.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "Please enter your parmanent address post code !", "Error", JOptionPane.ERROR_MESSAGE);
            return;

        }
                                                        
                                                        
       Statement stmt;
       stmt= con.createStatement();
       String sql1="Select Customer_name,Age,Customer_phone from customers where Customer_name= '" + name.getText() + "' and Age='" + age.getText()+"'and Customer_phone='" +phone.getText()+ "'";
      rs=stmt.executeQuery(sql1);
      if(rs.next()){
        JOptionPane.showMessageDialog( this, "Record already exists","Error", JOptionPane.ERROR_MESSAGE);
        return;
      }
      
           
            String sql= "insert into customers(Customer_id,Customer_type_code,Customer_name, Age, Gender, Customer_phone, Customer_mail, User_id, User_pass,Image, Security_question)values(?,?,'"+ name.getText() + "','"+ age.getText() + "','"+ gender.getSelectedItem() + "','"+ phone.getText()+ "','" + mail.getText() + "','"+ user_name.getText() +"','"+ user_pass.getText() + "',?,'"+ fav_pet.getText() +"')";
            String sql3="insert into address(Address_id, Customer_id, Present_address, Pre_house_no, Pre_house_line, Pre_Office_line, Pre_post_code, Parmanent_address, Par_house_no, Par_house_line, Par_office_line, Par_post_code)values(?,?,'"+ present_add.getText() + "','"+ present_house_no.getText() + "','"+ present_house_line.getText() + "','"+ present_office_line.getText()+ "','" + present_post_code.getText() + "','"+ parmanent_add.getText() +"','"+ parmanent_house_no.getText() + "','"+ parmanent_house_line.getText() +"','"+ parmanent_office_line.getText() +"','"+ parmanent_post_code.getText() +"')";
            String sql5="insert into accounts(Account_id,Account_type_code, Customer_id, Account_name, Account_opening) values (?,?,?,'"+acc_name.getText()+"','"+((JTextField)date.getDateEditor().getUiComponent()).getText()+"')";
            String sql6="insert into balance_history(Account_id, Current_balance, Withdrawable) values (?,'"+ m +"','"+ n +"')";          
            
    String query1= "select * from customer_type where Customer_type= '" +occ.getSelectedItem()+ "'";
    pst=con.prepareStatement(query1);
    rs= pst.executeQuery();
        if(rs.next()){
            String id = rs.getString("Customer_type_code").trim();
            cus_type_code=Integer.parseInt(id);
        }
        
        String query2= "select * from account_type where Account_type= '" +acc_type.getSelectedItem()+ "'";
    pst=con.prepareStatement(query2);
    rs= pst.executeQuery();
        if(rs.next()){
            String id = rs.getString("Account_type_code").trim();
            acc_type_code=Integer.parseInt(id);
        }
        
            pst=con.prepareStatement(sql);
            pst.setInt(1,c_id);
            pst.setInt(2,cus_type_code);
            pst.setBytes(3,p_image);
            pst.execute();
            
            pst=con.prepareStatement(sql3);
            pst.setInt(1,address_id);
            pst.setInt(2,c_id);
            pst.execute();
            
            pst=con.prepareStatement(sql5);
            pst.setInt(1,account_id);
            pst.setInt(2,acc_type_code);
            pst.setInt(3,c_id);
            pst.execute();
            
            pst=con.prepareStatement(sql6);
            pst.setInt(1,account_id);
            pst.execute();
            
            
            JOptionPane.showMessageDialog(this,"Inserted","Customer",JOptionPane.INFORMATION_MESSAGE);
            DefaultTableModel model = (DefaultTableModel)jTable_Display_Users.getModel();
            model.setRowCount(0);
            Show_Users_In_JTable();
            
             name.setText("");
         age.setText("");
         gender.setSelectedIndex(-1);
         phone.setText("");
        mail.setText("");
       occ.setSelectedIndex(-1);
         user_name.setText("");
         user_pass.setText("");
         acc_type.setSelectedIndex(-1);
         acc_name.setText("");
         fav_pet.setText("");
         date.setDate(null);
         lbl_img.setIcon(null);
         jRadioButton1.setSelected(false);
         hidelvl.setText("");
               parmanent_add.setText("");
               present_add.setText("");
               parmanent_house_no.setText("");
               present_house_no.setText("");
               parmanent_house_line.setText("");
               present_house_line.setText("");
               parmanent_office_line.setText("");
               present_office_line.setText("");
               parmanent_post_code.setText("");
               present_post_code.setText("");
               search.setText("");
            
            
        }
     catch(HeadlessException | SQLException ex){
            JOptionPane.showMessageDialog(this,ex);
        }
}
else{
    
    JOptionPane.showMessageDialog(this,"Clear all the field first","Error",JOptionPane.ERROR_MESSAGE);
}
        
// TODO add your handling code here:
    }//GEN-LAST:event_insertActionPerformed

    private void clearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearActionPerformed
              
         name.setText("");
         age.setText("");
         gender.setSelectedIndex(-1);
         phone.setText("");
        mail.setText("");
       occ.setSelectedIndex(-1);
         user_name.setText("");
         user_pass.setText("");
         acc_type.setSelectedIndex(-1);
         acc_name.setText("");
         fav_pet.setText("");
         date.setDate(null);
         lbl_img.setIcon(null);
         jRadioButton1.setSelected(false);
         hidelvl.setText("");
               parmanent_add.setText("");
               present_add.setText("");
               parmanent_house_no.setText("");
               present_house_no.setText("");
               parmanent_house_line.setText("");
               present_house_line.setText("");
               parmanent_office_line.setText("");
               present_office_line.setText("");
               parmanent_post_code.setText("");
               present_post_code.setText("");
               search.setText("");
    }//GEN-LAST:event_clearActionPerformed

    private void jTable_Display_UsersMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable_Display_UsersMouseClicked
       int i = jTable_Display_Users.getSelectedRow();
        
         // get the model from the jtable
       DefaultTableModel model = (DefaultTableModel)jTable_Display_Users.getModel();
       
       // Show_Users_In_JTable();

     //   TableModel model = jTable_Display_Users.getModel();
        
         // Display Slected Row In JTexteFields
       hidelvl.setText(model.getValueAt(i,0).toString());

       name.setText(model.getValueAt(i,1).toString());

        phone.setText(model.getValueAt(i,2).toString());

        age.setText(model.getValueAt(i,3).toString()); 
        
        FillAccount();
  
    }//GEN-LAST:event_jTable_Display_UsersMouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
             con=Connect.ConnectDB();
        try{

            Image image;
            
           String x=search.getText();
            
            //DefaultTableModel model;
        String query5= "select * from customers where Customer_id= '" +x+ "'";
        pst=con.prepareStatement(query5);
        rs= pst.executeQuery();
        if(rs.next()){
            String m = rs.getString("Customer_name").trim();
            String ag = rs.getString("Age").trim();
            String ph = rs.getString("Customer_phone").trim();
            String ge = rs.getString("Gender").trim();
            String cusmail = rs.getString("Customer_mail").trim();
            String uid = rs.getString("User_id").trim();
            String upass = rs.getString("User_pass").trim();
            String type = rs.getString("Customer_type_code").trim();
            String ans = rs.getString("Security_question").trim();
             imageBytes=rs.getBytes("Image");
            image=getToolkit().createImage(imageBytes);
            ImageIcon icon = new ImageIcon(image);
            Image im=icon.getImage();
            Image myImage=im.getScaledInstance(lbl_img.getWidth(), lbl_img.getHeight(), Image.SCALE_SMOOTH);
            ImageIcon newicon = new ImageIcon(myImage);
            lbl_img.setIcon(newicon);
            name.setText(m);
             age.setText(ag);
             phone.setText(ph);
            gender.setSelectedItem(ge);
            mail.setText(cusmail);   
             user_name.setText(uid);
             user_pass.setText(upass);
             fav_pet.setText(ans);
               String query10= "select * from customer_type where Customer_type_code= '" +type+ "'";
                pst=con.prepareStatement(query10);
                rs= pst.executeQuery();
              if(rs.next()){
              String cusype = rs.getString("Customer_type").trim();
             occ.setSelectedItem(cusype);
                 }
        }
        else{
            JOptionPane.showMessageDialog(this, "No Record Exist !", "Error", JOptionPane.ERROR_MESSAGE);
             name.setText("");
         age.setText("");
         gender.setSelectedIndex(-1);
         phone.setText("");
        mail.setText("");
       occ.setSelectedIndex(-1);
         user_name.setText("");
         user_pass.setText("");
         acc_type.setSelectedIndex(-1);
         acc_name.setText("");
         fav_pet.setText("");
         date.setDate(null);
               parmanent_add.setText("");
               present_add.setText("");
               parmanent_house_no.setText("");
               present_house_no.setText("");
               parmanent_house_line.setText("");
               present_house_line.setText("");
               parmanent_office_line.setText("");
               present_office_line.setText("");
               parmanent_post_code.setText("");
               present_post_code.setText("");
              search.setText("");
            return;
        }
       
        
        String query6= "select * from accounts where Customer_id= '" +x+ "'";
        pst=con.prepareStatement(query6);
        rs= pst.executeQuery();
        if(rs.next()){
           String opdate = rs.getString("Account_opening").trim(); 
           String accountname = rs.getString("Account_name").trim(); 
           String accountype = rs.getString("Account_type_code").trim();
           date.setDate(new SimpleDateFormat("yyyy-MM-dd").parse(opdate));
           acc_name.setText(accountname);
           
            String query9= "select * from account_type where Account_type_code= '" +accountype+ "'";
        pst=con.prepareStatement(query9);
        rs= pst.executeQuery();
        if(rs.next()){
           String acctype = rs.getString("Account_type").trim();
           acc_type.setSelectedItem(acctype);
                }
        }
        
        
        String query11= "select * from address where Customer_id= '" +x+ "'";
        pst=con.prepareStatement(query11);
        rs= pst.executeQuery();
        if(rs.next()){
           String a1 = rs.getString("Present_address").trim(); 
           String a2 = rs.getString("Pre_house_no").trim(); 
           String a3 = rs.getString("Pre_house_line").trim(); 
           String a4 = rs.getString("Pre_Office_line").trim(); 
           String a5 = rs.getString("Pre_post_code").trim(); 
           String a6 = rs.getString("Parmanent_address").trim(); 
           String a7 = rs.getString("Par_house_no").trim(); 
           String a8 = rs.getString("Par_house_line").trim();
           String a9 = rs.getString("Par_office_line").trim(); 
           String a10 = rs.getString("Par_post_code").trim();
               parmanent_add.setText(a6);
               present_add.setText(a1);
               parmanent_house_no.setText(a7);
               present_house_no.setText(a2);
               parmanent_house_line.setText(a8);
               present_house_line.setText(a3);
               parmanent_office_line.setText(a9);
               present_office_line.setText(a4);
               parmanent_post_code.setText(a10);
               present_post_code.setText(a5);
        }
   
        }
 
        catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
        
// TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateActionPerformed

        try{
            con=Connect.ConnectDB();
            
            String id1=hidelvl.getText();
        
int final_id=Integer.parseInt(id1);

if(filename==null){

            String sql31= "update customers set Customer_type_code=?,Customer_name='"+ name.getText() + "', Age='"+ age.getText() + "',Gender='"+ gender.getSelectedItem() + "',Customer_phone='"+ phone.getText()+ "',Customer_mail='" + mail.getText() + "',User_id='"+ user_name.getText() +"',User_pass='"+ user_pass.getText() + "', Security_question='"+fav_pet.getText() +"' where Customer_id='"+final_id+"'";          
               String query41= "select * from customer_type where Customer_type= '" +occ.getSelectedItem()+ "'";
    pst=con.prepareStatement(query41);
    rs= pst.executeQuery();
        if(rs.next()){
            String id = rs.getString("Customer_type_code").trim();
            cus_type_code=Integer.parseInt(id);
            }
            pst=con.prepareStatement(sql31);
            pst.setInt(1,cus_type_code);
            pst.executeUpdate();          
}
else{
             try{
            File image = new File(filename);
            FileInputStream fis=new FileInputStream(image);
            ByteArrayOutputStream bos=new ByteArrayOutputStream();
            byte[] buf=new byte[1024];
            for(int readNum;(readNum=fis.read(buf))!=-1;){
                bos.write(buf,0,readNum);
            }
            p_image= bos.toByteArray();
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
              String sql31= "update customers set Customer_type_code=?,Customer_name='"+ name.getText() + "', Age='"+ age.getText() + "',Gender='"+ gender.getSelectedItem() + "',Customer_phone='"+ phone.getText()+ "',Customer_mail='" + mail.getText() + "',User_id='"+ user_name.getText() +"',User_pass='"+ user_pass.getText() + "',Image=?, Security_question='"+fav_pet.getText() +"' where Customer_id='"+final_id+"'";          
               String query41= "select * from customer_type where Customer_type= '" +occ.getSelectedItem()+ "'";
    pst=con.prepareStatement(query41);
    rs= pst.executeQuery();
        if(rs.next()){
            String id = rs.getString("Customer_type_code").trim();
            cus_type_code=Integer.parseInt(id);
            }
            pst=con.prepareStatement(sql31);
            pst.setInt(1,cus_type_code);
            pst.setBytes(2,p_image);
            pst.executeUpdate();
    
}
            
          String sql32="update address set Present_address='"+ present_add.getText() + "',Pre_house_no='"+ present_house_no.getText() + "',Pre_house_line='"+ present_house_line.getText() + "',Pre_Office_line='"+ present_office_line.getText()+ "',Pre_post_code='" + present_post_code.getText() + "',Parmanent_address='"+ parmanent_add.getText() +"',Par_house_no='"+ parmanent_house_no.getText() + "',Par_house_line='"+ parmanent_house_line.getText() +"',Par_office_line='"+ parmanent_office_line.getText() +"',Par_post_code='"+ parmanent_post_code.getText() +"' where Customer_id='"+final_id+"' ";  
           pst=con.prepareStatement(sql32);
           pst.executeUpdate();
           
           
      String sql33="update accounts set Account_type_code=?,Account_name='"+acc_name.getText()+"',Account_opening='"+((JTextField)date.getDateEditor().getUiComponent()).getText()+"' where Customer_id='"+final_id+"'";       
        String query42= "select * from account_type where Account_type= '" +acc_type.getSelectedItem()+ "'";
    pst=con.prepareStatement(query42);
    rs= pst.executeQuery();
        if(rs.next()){
            String id = rs.getString("Account_type_code").trim();
            acc_type_code=Integer.parseInt(id);
        }
        pst=con.prepareStatement(sql33);
            pst.setInt(1,acc_type_code);
          pst.executeUpdate();
        
        DefaultTableModel model = (DefaultTableModel)jTable_Display_Users.getModel();
               model.setRowCount(0);
               Show_Users_In_JTable();
               
               JOptionPane.showMessageDialog(null, "Data Updated Succefully");
            
            }
        catch(Exception e){
            
            JOptionPane.showMessageDialog(this,e);
        }
            
    }//GEN-LAST:event_updateActionPerformed

    private void searchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchKeyReleased
           DefaultTableModel table1= (DefaultTableModel)jTable_Display_Users.getModel();
            String src=search.getText().toLowerCase();
            TableRowSorter<DefaultTableModel> tr=new TableRowSorter<DefaultTableModel>(table1);
            jTable_Display_Users.setRowSorter(tr);
            tr.setRowFilter(RowFilter.regexFilter(src));        // TODO add your handling code here:
    }//GEN-LAST:event_searchKeyReleased

    private void jLabel45MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel45MouseClicked
this.setState(JFrame.ICONIFIED);          // TODO add your handling code here:
    }//GEN-LAST:event_jLabel45MouseClicked

    private void search1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_search1FocusGained
search1.setText("");
search1.setForeground(Color.BLACK);        // TODO add your handling code here:
    }//GEN-LAST:event_search1FocusGained

    private void search1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_search1FocusLost
        // TODO add your handling code here:
    }//GEN-LAST:event_search1FocusLost

    private void search1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_search1KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_search1KeyPressed

    private void search1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_search1KeyReleased
            DefaultTableModel table2= (DefaultTableModel)Panel2_table.getModel();
            String src=search1.getText().toLowerCase();
            TableRowSorter<DefaultTableModel> tr=new TableRowSorter<DefaultTableModel>(table2);
            Panel2_table.setRowSorter(tr);
            tr.setRowFilter(RowFilter.regexFilter(src));         // TODO add your handling code here:
    }//GEN-LAST:event_search1KeyReleased

    private void search1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_search1KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_search1KeyTyped

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void search1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_search1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_search1ActionPerformed

    private void search2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_search2FocusGained
search2.setText("");
search2.setForeground(Color.BLACK);         // TODO add your handling code here:
    }//GEN-LAST:event_search2FocusGained

    private void search2FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_search2FocusLost
        // TODO add your handling code here:
    }//GEN-LAST:event_search2FocusLost

    private void search2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_search2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_search2ActionPerformed

    private void search2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_search2KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_search2KeyPressed

    private void search2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_search2KeyReleased
DefaultTableModel table1= (DefaultTableModel)Panel_Table3.getModel();
        String src=search2.getText().toLowerCase();
            TableRowSorter<DefaultTableModel> tr=new TableRowSorter<DefaultTableModel>(table1);
            Panel_Table3.setRowSorter(tr);
            tr.setRowFilter(RowFilter.regexFilter(src));          // TODO add your handling code here:
    }//GEN-LAST:event_search2KeyReleased

    private void search2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_search2KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_search2KeyTyped

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void search5FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_search5FocusGained
search5.setText("");
search5.setForeground(Color.BLACK);            // TODO add your handling code here:
    }//GEN-LAST:event_search5FocusGained

    private void search5FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_search5FocusLost
        // TODO add your handling code here:
    }//GEN-LAST:event_search5FocusLost

    private void search5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_search5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_search5ActionPerformed

    private void search5KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_search5KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_search5KeyPressed

    private void search5KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_search5KeyReleased
DefaultTableModel table12= (DefaultTableModel)Panel3_table.getModel();
        String src=search5.getText().toLowerCase();
            TableRowSorter<DefaultTableModel> tr=new TableRowSorter<DefaultTableModel>(table12);
            Panel3_table.setRowSorter(tr);
            tr.setRowFilter(RowFilter.regexFilter(src));          // TODO add your handling code here:
    }//GEN-LAST:event_search5KeyReleased

    private void search5KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_search5KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_search5KeyTyped

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void lastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lastActionPerformed
          genC_ID();
        int z1=c_id;

       con=Connect.ConnectDB();
        try{

            Image image;
            
           int x=z1-1;
            
            //DefaultTableModel model;
        String query5= "select * from customers where Customer_id= '" +x+ "'";
        pst=con.prepareStatement(query5);
        rs= pst.executeQuery();
        if(rs.next()){
            String m = rs.getString("Customer_name").trim();
            String ag = rs.getString("Age").trim();
            String ph = rs.getString("Customer_phone").trim();
            String ge = rs.getString("Gender").trim();
            String cusmail = rs.getString("Customer_mail").trim();
            String uid = rs.getString("User_id").trim();
            String upass = rs.getString("User_pass").trim();
            String type = rs.getString("Customer_type_code").trim();
            String ans = rs.getString("Security_question").trim();
             imageBytes=rs.getBytes("Image");
            image=getToolkit().createImage(imageBytes);
            ImageIcon icon = new ImageIcon(image);
            Image im=icon.getImage();
            Image myImage=im.getScaledInstance(lbl_img.getWidth(), lbl_img.getHeight(), Image.SCALE_SMOOTH);
            ImageIcon newicon = new ImageIcon(myImage);
            lbl_img.setIcon(newicon);
            name.setText(m);
             age.setText(ag);
             phone.setText(ph);
            gender.setSelectedItem(ge);
            mail.setText(cusmail);   
             user_name.setText(uid);
             user_pass.setText(upass);
             fav_pet.setText(ans);
               String query10= "select * from customer_type where Customer_type_code= '" +type+ "'";
                pst=con.prepareStatement(query10);
                rs= pst.executeQuery();
              if(rs.next()){
              String cusype = rs.getString("Customer_type").trim();
             occ.setSelectedItem(cusype);
                 }
        }
        else{
            JOptionPane.showMessageDialog(this, "No Record Exist !", "Error", JOptionPane.ERROR_MESSAGE);
             name.setText("");
         age.setText("");
         gender.setSelectedIndex(-1);
         phone.setText("");
        mail.setText("");
       occ.setSelectedIndex(-1);
         user_name.setText("");
         user_pass.setText("");
         acc_type.setSelectedIndex(-1);
         acc_name.setText("");
         fav_pet.setText("");
         date.setDate(null);
               parmanent_add.setText("");
               present_add.setText("");
               parmanent_house_no.setText("");
               present_house_no.setText("");
               parmanent_house_line.setText("");
               present_house_line.setText("");
               parmanent_office_line.setText("");
               present_office_line.setText("");
               parmanent_post_code.setText("");
               present_post_code.setText("");
              search.setText("");
            return;
        }
       
        
        String query6= "select * from accounts where Customer_id= '" +x+ "'";
        pst=con.prepareStatement(query6);
        rs= pst.executeQuery();
        if(rs.next()){
           String opdate = rs.getString("Account_opening").trim(); 
           String accountname = rs.getString("Account_name").trim(); 
           String accountype = rs.getString("Account_type_code").trim();
           date.setDate(new SimpleDateFormat("yyyy-MM-dd").parse(opdate));
           acc_name.setText(accountname);
           
            String query9= "select * from account_type where Account_type_code= '" +accountype+ "'";
        pst=con.prepareStatement(query9);
        rs= pst.executeQuery();
        if(rs.next()){
           String acctype = rs.getString("Account_type").trim();
           acc_type.setSelectedItem(acctype);
                }
        }
        
        
        String query11= "select * from address where Customer_id= '" +x+ "'";
        pst=con.prepareStatement(query11);
        rs= pst.executeQuery();
        if(rs.next()){
           String a1 = rs.getString("Present_address").trim(); 
           String a2 = rs.getString("Pre_house_no").trim(); 
           String a3 = rs.getString("Pre_house_line").trim(); 
           String a4 = rs.getString("Pre_Office_line").trim(); 
           String a5 = rs.getString("Pre_post_code").trim(); 
           String a6 = rs.getString("Parmanent_address").trim(); 
           String a7 = rs.getString("Par_house_no").trim(); 
           String a8 = rs.getString("Par_house_line").trim();
           String a9 = rs.getString("Par_office_line").trim(); 
           String a10 = rs.getString("Par_post_code").trim();
               parmanent_add.setText(a6);
               present_add.setText(a1);
               parmanent_house_no.setText(a7);
               present_house_no.setText(a2);
               parmanent_house_line.setText(a8);
               present_house_line.setText(a3);
               parmanent_office_line.setText(a9);
               present_office_line.setText(a4);
               parmanent_post_code.setText(a10);
               present_post_code.setText(a5);
        }
   
        }
 
        catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_lastActionPerformed

    private void firstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_firstActionPerformed

        
        int z2=0;
        
       
 
  con=Connect.ConnectDB();
        try{
                  
            Image image;
                    
             try{ 
      String sql= "select Customer_id from customers order by Customer_id asc limit 1";
      pst=con.prepareStatement(sql);
      rs= pst.executeQuery();
        if(rs.next()){
            String id3 = rs.getString("Customer_id").trim();
            z2=Integer.parseInt(id3);
        }
       }
       catch(Exception e){
          JOptionPane.showMessageDialog(null,e); 
       }
           
            
            //DefaultTableModel model;
        String query5= "select * from customers where Customer_id= '" +z2+ "'";
        pst=con.prepareStatement(query5);
        rs= pst.executeQuery();
        if(rs.next()){
            String m = rs.getString("Customer_name").trim();
            String ag = rs.getString("Age").trim();
            String ph = rs.getString("Customer_phone").trim();
            String ge = rs.getString("Gender").trim();
            String cusmail = rs.getString("Customer_mail").trim();
            String uid = rs.getString("User_id").trim();
            String upass = rs.getString("User_pass").trim();
            String type = rs.getString("Customer_type_code").trim();
            String ans = rs.getString("Security_question").trim();
             imageBytes=rs.getBytes("Image");
            image=getToolkit().createImage(imageBytes);
            ImageIcon icon = new ImageIcon(image);
            Image im=icon.getImage();
            Image myImage=im.getScaledInstance(lbl_img.getWidth(), lbl_img.getHeight(), Image.SCALE_SMOOTH);
            ImageIcon newicon = new ImageIcon(myImage);
            lbl_img.setIcon(newicon);
            name.setText(m);
             age.setText(ag);
             phone.setText(ph);
            gender.setSelectedItem(ge);
            mail.setText(cusmail);   
             user_name.setText(uid);
             user_pass.setText(upass);
             fav_pet.setText(ans);
               String query10= "select * from customer_type where Customer_type_code= '" +type+ "'";
                pst=con.prepareStatement(query10);
                rs= pst.executeQuery();
              if(rs.next()){
              String cusype = rs.getString("Customer_type").trim();
             occ.setSelectedItem(cusype);
                 }
        }
        else{
            JOptionPane.showMessageDialog(this, "No Record Exist !", "Error", JOptionPane.ERROR_MESSAGE);
             name.setText("");
         age.setText("");
         gender.setSelectedIndex(-1);
         phone.setText("");
        mail.setText("");
       occ.setSelectedIndex(-1);
         user_name.setText("");
         user_pass.setText("");
         acc_type.setSelectedIndex(-1);
         acc_name.setText("");
         fav_pet.setText("");
         date.setDate(null);
               parmanent_add.setText("");
               present_add.setText("");
               parmanent_house_no.setText("");
               present_house_no.setText("");
               parmanent_house_line.setText("");
               present_house_line.setText("");
               parmanent_office_line.setText("");
               present_office_line.setText("");
               parmanent_post_code.setText("");
               present_post_code.setText("");
              search.setText("");
            return;
        }
       
        
        String query6= "select * from accounts where Customer_id= '" +z2+ "'";
        pst=con.prepareStatement(query6);
        rs= pst.executeQuery();
        if(rs.next()){
           String opdate = rs.getString("Account_opening").trim(); 
           String accountname = rs.getString("Account_name").trim(); 
           String accountype = rs.getString("Account_type_code").trim();
           date.setDate(new SimpleDateFormat("yyyy-MM-dd").parse(opdate));
           acc_name.setText(accountname);
           
            String query9= "select * from account_type where Account_type_code= '" +accountype+ "'";
        pst=con.prepareStatement(query9);
        rs= pst.executeQuery();
        if(rs.next()){
           String acctype = rs.getString("Account_type").trim();
           acc_type.setSelectedItem(acctype);
                }
        }
        
        
        String query11= "select * from address where Customer_id= '" +z2+ "'";
        pst=con.prepareStatement(query11);
        rs= pst.executeQuery();
        if(rs.next()){
           String a1 = rs.getString("Present_address").trim(); 
           String a2 = rs.getString("Pre_house_no").trim(); 
           String a3 = rs.getString("Pre_house_line").trim(); 
           String a4 = rs.getString("Pre_Office_line").trim(); 
           String a5 = rs.getString("Pre_post_code").trim(); 
           String a6 = rs.getString("Parmanent_address").trim(); 
           String a7 = rs.getString("Par_house_no").trim(); 
           String a8 = rs.getString("Par_house_line").trim();
           String a9 = rs.getString("Par_office_line").trim(); 
           String a10 = rs.getString("Par_post_code").trim();
               parmanent_add.setText(a6);
               present_add.setText(a1);
               parmanent_house_no.setText(a7);
               present_house_no.setText(a2);
               parmanent_house_line.setText(a8);
               present_house_line.setText(a3);
               parmanent_office_line.setText(a9);
               present_office_line.setText(a4);
               parmanent_post_code.setText(a10);
               present_post_code.setText(a5);
        }
   
        }
 
        catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
 
 
        
// TODO add your handling code here:
    }//GEN-LAST:event_firstActionPerformed

    private void nextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextActionPerformed
if(!hidelvl.getText().equals(""))
{
    String z3=hidelvl.getText();

int x= Integer.parseInt(z3);
x=x+1;
        genC_ID();
        int m1=c_id +1;
        
if(x!=m1){
    
      con=Connect.ConnectDB();
        try{
    Image image;
    hidelvl.setText(Integer.toString(x));
            //DefaultTableModel model;
        String query5= "select * from customers where Customer_id= '" +x+ "'";
        pst=con.prepareStatement(query5);
        rs= pst.executeQuery();
        if(rs.next()){
            String m = rs.getString("Customer_name").trim();
            String ag = rs.getString("Age").trim();
            String ph = rs.getString("Customer_phone").trim();
            String ge = rs.getString("Gender").trim();
            String cusmail = rs.getString("Customer_mail").trim();
            String uid = rs.getString("User_id").trim();
            String upass = rs.getString("User_pass").trim();
            String type = rs.getString("Customer_type_code").trim();
            String ans = rs.getString("Security_question").trim();
             imageBytes=rs.getBytes("Image");
            image=getToolkit().createImage(imageBytes);
            ImageIcon icon = new ImageIcon(image);
            Image im=icon.getImage();
            Image myImage=im.getScaledInstance(lbl_img.getWidth(), lbl_img.getHeight(), Image.SCALE_SMOOTH);
            ImageIcon newicon = new ImageIcon(myImage);
            lbl_img.setIcon(newicon);
            name.setText(m);
             age.setText(ag);
             phone.setText(ph);
            gender.setSelectedItem(ge);
            mail.setText(cusmail);   
             user_name.setText(uid);
             user_pass.setText(upass);
             fav_pet.setText(ans);
               String query10= "select * from customer_type where Customer_type_code= '" +type+ "'";
                pst=con.prepareStatement(query10);
                rs= pst.executeQuery();
              if(rs.next()){
              String cusype = rs.getString("Customer_type").trim();
             occ.setSelectedItem(cusype);
                 }
        }
        else{
            JOptionPane.showMessageDialog(this, "No Record Exist !", "Error", JOptionPane.ERROR_MESSAGE);
             name.setText("");
         age.setText("");
         gender.setSelectedIndex(-1);
         phone.setText("");
        mail.setText("");
       occ.setSelectedIndex(-1);
         user_name.setText("");
         user_pass.setText("");
         acc_type.setSelectedIndex(-1);
         acc_name.setText("");
         fav_pet.setText("");
         date.setDate(null);
               parmanent_add.setText("");
               present_add.setText("");
               parmanent_house_no.setText("");
               present_house_no.setText("");
               parmanent_house_line.setText("");
               present_house_line.setText("");
               parmanent_office_line.setText("");
               present_office_line.setText("");
               parmanent_post_code.setText("");
               present_post_code.setText("");
              search.setText("");
            return;
        }
       
        
        String query6= "select * from accounts where Customer_id= '" +x+ "'";
        pst=con.prepareStatement(query6);
        rs= pst.executeQuery();
        if(rs.next()){
           String opdate = rs.getString("Account_opening").trim(); 
           String accountname = rs.getString("Account_name").trim(); 
           String accountype = rs.getString("Account_type_code").trim();
           date.setDate(new SimpleDateFormat("yyyy-MM-dd").parse(opdate));
           acc_name.setText(accountname);
           
            String query9= "select * from account_type where Account_type_code= '" +accountype+ "'";
        pst=con.prepareStatement(query9);
        rs= pst.executeQuery();
        if(rs.next()){
           String acctype = rs.getString("Account_type").trim();
           acc_type.setSelectedItem(acctype);
                }
        }
        
        
        String query11= "select * from address where Customer_id= '" +x+ "'";
        pst=con.prepareStatement(query11);
        rs= pst.executeQuery();
        if(rs.next()){
           String a1 = rs.getString("Present_address").trim(); 
           String a2 = rs.getString("Pre_house_no").trim(); 
           String a3 = rs.getString("Pre_house_line").trim(); 
           String a4 = rs.getString("Pre_Office_line").trim(); 
           String a5 = rs.getString("Pre_post_code").trim(); 
           String a6 = rs.getString("Parmanent_address").trim(); 
           String a7 = rs.getString("Par_house_no").trim(); 
           String a8 = rs.getString("Par_house_line").trim();
           String a9 = rs.getString("Par_office_line").trim(); 
           String a10 = rs.getString("Par_post_code").trim();
               parmanent_add.setText(a6);
               present_add.setText(a1);
               parmanent_house_no.setText(a7);
               present_house_no.setText(a2);
               parmanent_house_line.setText(a8);
               present_house_line.setText(a3);
               parmanent_office_line.setText(a9);
               present_office_line.setText(a4);
               parmanent_post_code.setText(a10);
               present_post_code.setText(a5);
        }
   
        }
 
        catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }   
}  
}// TODO add your handling code here:
    }//GEN-LAST:event_nextActionPerformed

 
    void setColor(JPanel panel){
    panel.setBackground(new Color(102,0,102));
}
void resetColor(JPanel panel){
    panel.setBackground(new Color(47,3,54));
}

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new menu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable Panel2_table;
    private javax.swing.JTable Panel3_table;
    private javax.swing.JTable Panel4_table;
    private javax.swing.JTable Panel5_table;
    private javax.swing.JTable Panel_Table3;
    private javax.swing.JTextField Tsum;
    private javax.swing.JTextField acc_name;
    private javax.swing.JComboBox acc_type;
    private javax.swing.JTextField age;
    private javax.swing.JButton btnImage;
    private javax.swing.JPanel btn_about;
    private javax.swing.JPanel btn_about1;
    private javax.swing.JPanel btn_acc_table;
    private javax.swing.JPanel btn_add_table;
    private javax.swing.JPanel btn_balance_table;
    private javax.swing.JPanel btn_cust_manipulation;
    private javax.swing.JPanel btn_cust_table;
    private javax.swing.JPanel btn_logout;
    private javax.swing.JPanel btn_purchase_table;
    private javax.swing.JPanel btn_rec_manipulation;
    private javax.swing.JPanel btn_sdb;
    private javax.swing.JPanel btn_service_table;
    private javax.swing.JPanel btn_transaction_table;
    private javax.swing.JButton clear;
    private com.toedter.calendar.JDateChooser date;
    private javax.swing.JLabel date1;
    private javax.swing.JButton delete;
    private javax.swing.JTextField fav_pet;
    private javax.swing.JButton first;
    private javax.swing.JComboBox gender;
    private javax.swing.JLabel hidelvl;
    private javax.swing.JPanel ind_about;
    private javax.swing.JPanel ind_about1;
    private javax.swing.JPanel ind_acc_table;
    private javax.swing.JPanel ind_add_table;
    private javax.swing.JPanel ind_balance_table;
    private javax.swing.JPanel ind_cust_manipulation;
    private javax.swing.JPanel ind_cust_table;
    private javax.swing.JPanel ind_logout;
    private javax.swing.JPanel ind_myacc;
    private javax.swing.JPanel ind_myacc3;
    private javax.swing.JPanel ind_purchase_table;
    private javax.swing.JPanel ind_service_table;
    private javax.swing.JPanel ind_transaction_table;
    private javax.swing.JButton insert;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JDesktopPane jDesktopPane1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTable jTable_Display_Users;
    private javax.swing.JButton last;
    private javax.swing.JLabel lbl_img;
    private javax.swing.JTextField mail;
    private javax.swing.JTextField name;
    private javax.swing.JButton next;
    private javax.swing.JComboBox occ;
    private javax.swing.JPanel panelHeader;
    private javax.swing.JTextArea parmanent_add;
    private javax.swing.JTextField parmanent_house_line;
    private javax.swing.JTextField parmanent_house_no;
    private javax.swing.JTextField parmanent_office_line;
    private javax.swing.JTextField parmanent_post_code;
    private javax.swing.JTextField phone;
    private javax.swing.JTextArea present_add;
    private javax.swing.JTextField present_house_line;
    private javax.swing.JTextField present_house_no;
    private javax.swing.JTextField present_office_line;
    private javax.swing.JTextField present_post_code;
    private javax.swing.JButton previous;
    private javax.swing.JTextField search;
    private javax.swing.JTextField search1;
    private javax.swing.JTextField search2;
    private javax.swing.JTextField search5;
    private javax.swing.JLabel time;
    private javax.swing.JButton update;
    private javax.swing.JTextField user_name;
    private javax.swing.JPasswordField user_pass;
    // End of variables declaration//GEN-END:variables

   
}
