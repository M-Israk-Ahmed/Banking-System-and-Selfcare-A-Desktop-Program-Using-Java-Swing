CREATE DATABASE  IF NOT EXISTS `customer_bank_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */;
USE `customer_bank_db`;
-- MySQL dump 10.13  Distrib 8.0.15, for Win64 (x86_64)
--
-- Host: localhost    Database: customer_bank_db
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `accounts` (
  `Account_id` int(11) NOT NULL,
  `Account_type_code` int(11) NOT NULL,
  `Customer_id` int(11) NOT NULL,
  `Account_name` varchar(45) NOT NULL,
  `Account_opening` date NOT NULL,
  PRIMARY KEY (`Account_id`),
  KEY `Customer_id_idx` (`Customer_id`),
  KEY `Account_type_code_idx` (`Account_type_code`),
  CONSTRAINT `Account_type_code` FOREIGN KEY (`Account_type_code`) REFERENCES `account_type` (`Account_type_code`),
  CONSTRAINT `Customer_id` FOREIGN KEY (`Customer_id`) REFERENCES `customers` (`Customer_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` VALUES (4001,1,1,'M. Israk Ahmed','2019-04-11'),(4002,2,2,'S M Mamun','2019-04-11'),(4003,3,3,'N Nirob','2019-04-11'),(4004,1,4,'A S Salman','2019-04-11'),(4005,2,5,'A Hannan','2019-04-11'),(4006,3,6,'A A Asaad','2019-04-11'),(4007,1,7,'P Udas','2019-04-11'),(4008,2,8,'Ponkoj Sarkar','2019-04-11'),(4009,3,9,'Orko Ghos','2019-04-11'),(4010,2,10,'L Banu','2019-04-10'),(4011,3,11,'R Khanom','2019-04-09'),(4012,1,12,'Jerin Akhter','2019-04-09'),(4013,3,13,'Salma Imtiaz','2019-04-08'),(4014,2,14,'Opi Karim','2019-04-10');
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-05-21 19:05:08
