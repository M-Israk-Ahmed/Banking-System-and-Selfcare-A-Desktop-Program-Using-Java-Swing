CREATE DATABASE  IF NOT EXISTS `customer_bank_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */;
USE `customer_bank_db`;
-- MySQL dump 10.13  Distrib 8.0.15, for Win64 (x86_64)
--
-- Host: localhost    Database: customer_bank_db
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product_and_services`
--

DROP TABLE IF EXISTS `product_and_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `product_and_services` (
  `Service_code` int(11) NOT NULL,
  `Merchant_id` int(11) NOT NULL,
  `Service_rating` int(11) NOT NULL,
  `Service_details` varchar(45) NOT NULL,
  PRIMARY KEY (`Service_code`),
  KEY `Merchant_id_idx` (`Merchant_id`),
  CONSTRAINT `Merchant_id` FOREIGN KEY (`Merchant_id`) REFERENCES `merchants` (`Merchant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_and_services`
--

LOCK TABLES `product_and_services` WRITE;
/*!40000 ALTER TABLE `product_and_services` DISABLE KEYS */;
INSERT INTO `product_and_services` VALUES (66771,221,3,'Fund Transfer'),(66772,222,5,'Fund Transfer'),(66773,221,4,'Fund Transfer'),(66774,221,4,'Fund Transfer'),(66775,221,4,'Fund Transfer'),(66776,222,5,'Fund Transfer'),(66777,221,2,'Fund Transfer'),(66778,221,3,'Fund Transfer'),(66779,222,4,'Fund Transfer'),(66780,221,4,'Fund Transfer'),(66781,222,4,'Fund Transfer'),(66782,221,3,'Fund Transfer'),(66783,221,4,'Fund Transfer'),(66784,221,3,'Fund Transfer'),(66785,222,3,'Fund Transfer'),(66786,221,3,'Fund Transfer'),(66787,221,5,'Fund Transfer'),(66788,222,5,'Fund Transfer'),(66789,222,1,'Fund Transfer'),(66790,221,3,'Fund Transfer'),(66791,221,4,'Fund Transfer'),(66792,221,3,'Fund Transfer'),(66793,221,3,'Fund Transfer'),(66794,222,3,'Fund Transfer'),(66795,222,4,'Fund Transfer'),(66796,222,3,'Fund Transfer'),(66797,222,3,'Fund Transfer'),(66798,222,4,'Fund Transfer'),(66799,221,1,'Fund Transfer'),(66800,222,4,'Fund Transfer'),(66801,222,3,'Fund Transfer'),(66802,221,2,'Fund Transfer'),(66803,221,2,'Fund Transfer'),(66804,222,4,'Fund Transfer'),(66805,222,2,'Fund Transfer'),(66806,221,3,'Fund Transfer'),(66807,222,5,'Fund Transfer'),(66808,222,4,'Fund Transfer'),(66809,222,4,'Fund Transfer');
/*!40000 ALTER TABLE `product_and_services` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-05-21 19:05:08
