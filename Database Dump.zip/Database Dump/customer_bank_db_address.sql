CREATE DATABASE  IF NOT EXISTS `customer_bank_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */;
USE `customer_bank_db`;
-- MySQL dump 10.13  Distrib 8.0.15, for Win64 (x86_64)
--
-- Host: localhost    Database: customer_bank_db
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `address`
--

DROP TABLE IF EXISTS `address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `address` (
  `Address_id` int(11) NOT NULL,
  `Customer_id` int(11) NOT NULL,
  `Present_address` varchar(45) NOT NULL,
  `Pre_house_no` varchar(45) NOT NULL,
  `Pre_house_line` int(11) NOT NULL,
  `Pre_Office_line` int(11) NOT NULL,
  `Pre_post_code` varchar(45) NOT NULL,
  `Parmanent_address` varchar(45) NOT NULL,
  `Par_house_no` varchar(45) NOT NULL,
  `Par_house_line` int(11) NOT NULL,
  `Par_office_line` int(11) NOT NULL,
  `Par_post_code` varchar(45) NOT NULL,
  PRIMARY KEY (`Address_id`),
  KEY `Customer_id_idx` (`Customer_id`),
  CONSTRAINT `Customer_id1` FOREIGN KEY (`Customer_id`) REFERENCES `customers` (`Customer_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address`
--

LOCK TABLES `address` WRITE;
/*!40000 ALTER TABLE `address` DISABLE KEYS */;
INSERT INTO `address` VALUES (501,1,'Sobhanbug,Dhanmondi,Dhaka','B-17/7',22343543,25233445,'1207','Sobhanbug,Dhanmondi,Dhaka','B-17/7',22343543,25233445,'1207'),(502,2,'Atibazar,Mohammadpur,Dhaka','A1',12213143,21434355,'1208','Atibazar,Mohammadpur,Dhaka','A1',12213143,21434355,'1208'),(503,3,'Atibazar,Mohammadpur,Dhaka','B1',4535235,2343255,'1208','Atibazar,Mohammadpur,Dhaka','B1',4535235,2343255,'1208'),(504,4,'Mirpur-10,Dhaka','C4',2343253,3252354,'1209','Mirpur-10,Dhaka','C4',2343253,3252354,'1209'),(505,5,'Dhanmondi,Dhaka','D4',34234523,42352345,'1207','Dhanmondi,Dhaka','D4',34234523,42352345,'1207'),(506,6,'Shonkor,Dhaka','G-45',5443435,4354367,'1208','Shonkor,Dhaka','G-45',5443435,4354367,'1208'),(507,7,'Bonani,Dhaka','A-4/3',354354,353545,'1203','Bonani,Dhaka','A-4/3',354354,353545,'1203'),(508,8,'Gulshan,Dhaka','C5',34545,64656,'1204','Gulshan,Dhaka','C5',34545,64656,'1204'),(509,9,'Kolabagan,dhaka','S-4/1',23242453,24235355,'1207','Kolabagan,dhaka','S-4/1',23242453,24235355,'1207'),(510,10,'Gulisthan,Dhaka','E1',321323,214345,'1211','Gulisthan,Dhaka','E1',321323,214345,'1211'),(511,11,'Shamoli,Dhaka','B-5',3546456,7567547,'1206','Shamoli,Dhaka','B-5',3546456,7567547,'1206'),(512,12,'Khamarbari,Dhaka','D23',2324443,3253453,'1209','Khamarbari,Dhaka','D23',2324443,3253453,'1209'),(513,13,'Adabor,Dhaka','S4',3243554,4546466,'1209','Adabor,Dhaka','S4',3243554,4546466,'1209'),(514,14,'Kurmitola,Dhaka','G22',3245358,3434434,'1216','Kurmitola,Dhaka','G22',3245358,3434434,'1216');
/*!40000 ALTER TABLE `address` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-05-21 19:05:08
